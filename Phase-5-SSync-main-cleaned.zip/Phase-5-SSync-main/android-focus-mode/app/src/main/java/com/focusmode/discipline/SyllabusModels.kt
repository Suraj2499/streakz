package com.focusmode.discipline

data class Subject(
    val id: String,
    val name: String
)

data class Chapter(
    val id: String,
    val subjectId: String,
    val name: String,
    val status: String,       // "pending" | "in-progress" | "completed"
    val totalLectures: Int
)

data class Lecture(
    val id: String,
    val chapterId: String,
    val number: Int,
    val status: String,       // "pending" | "in-progress" | "completed"
    val durationMs: Long
)

data class RevisionItem(
    val id: String,
    val chapterId: String,
    val chapterName: String,
    val scheduledDate: String // YYYY-MM-DD
)
