package com.focusmode.discipline

data class TaskItem(
    val id: String,
    val title: String,
    val status: String,   // "pending" | "completed"
    val date: String      // "YYYY-MM-DD"
)
