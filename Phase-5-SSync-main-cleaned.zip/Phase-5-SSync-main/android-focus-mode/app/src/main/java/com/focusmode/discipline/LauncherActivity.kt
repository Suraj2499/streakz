package com.focusmode.discipline

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * Entry point. Decides which screen to show and finishes itself immediately.
 *
 *   not logged in            -> AuthActivity
 *   logged in, no onboarding -> OnboardingActivity
 *   logged in + onboarded    -> DashboardActivity
 *
 * The Focus / blocking screen (MainActivity) is still available — it's now reached
 * via the bottom navigation bar from Dashboard.
 */
class LauncherActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val next = when {
            !UserPrefs.isLoggedIn(this) -> AuthActivity::class.java
            !UserPrefs.isOnboardingCompleted(this) -> OnboardingActivity::class.java
            else -> DashboardActivity::class.java
        }
        startActivity(Intent(this, next))
        finish()
    }
}
