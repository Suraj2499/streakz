package com.focusmode.discipline

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.concurrent.thread

class AppListActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var saveBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var adapter: AppListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_list)

        recycler = findViewById(R.id.appsRecycler)
        saveBtn = findViewById(R.id.saveBtn)
        progress = findViewById(R.id.progress)

        recycler.layoutManager = LinearLayoutManager(this)

        val already = Prefs.getBlockedPackages(this).toMutableSet()

        // Load installed apps off the main thread
        thread {
            val apps = loadInstalledApps(already)
            runOnUiThread {
                progress.visibility = android.view.View.GONE
                adapter = AppListAdapter(apps)
                recycler.adapter = adapter
            }
        }

        saveBtn.setOnClickListener {
            if (!::adapter.isInitialized) return@setOnClickListener
            val selected = adapter.getSelectedPackages()
            Prefs.setBlockedPackages(this, selected)
            Toast.makeText(this, "Saved ${selected.size} apps", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun loadInstalledApps(preselected: Set<String>): List<AppItem> {
        val pm = packageManager
        val flags = PackageManager.GET_META_DATA
        val all = pm.getInstalledApplications(flags)
        val selfPkg = packageName

        val result = ArrayList<AppItem>(all.size)
        for (info in all) {
            if (info.packageName == selfPkg) continue
            // Only apps that have a launcher intent (user can actually open them)
            pm.getLaunchIntentForPackage(info.packageName) ?: continue
            val label = try {
                pm.getApplicationLabel(info).toString()
            } catch (_: Exception) {
                info.packageName
            }
            val isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            result.add(
                AppItem(
                    packageName = info.packageName,
                    label = label,
                    isSystem = isSystem,
                    selected = preselected.contains(info.packageName)
                )
            )
        }
        return result.sortedWith(
            compareByDescending<AppItem> { it.selected }
                .thenBy { it.isSystem }
                .thenBy { it.label.lowercase() }
        )
    }
}
