package com.focusmode.discipline.sync

import com.focusmode.discipline.net.dto.ProgressDto
import com.focusmode.discipline.net.dto.UserDto
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Sealed type for every write that eventually needs to reach Supabase.
 *
 * - `key` is a UUID used as an idempotency key. Duplicate events with the same
 *   key are collapsed at enqueue time and skipped by the worker.
 * - Every case corresponds to exactly one RPC / table mutation in BackendRepo.
 */
@Serializable
sealed class SyncEvent {
    abstract val key: String

    @Serializable @SerialName("user_upsert")
    data class UserUpsert(override val key: String, val user: UserDto) : SyncEvent()

    @Serializable @SerialName("progress_upsert")
    data class ProgressUpsert(override val key: String, val progress: ProgressDto) : SyncEvent()

    @Serializable @SerialName("group_create")
    data class GroupCreate(
        override val key: String,
        val id: String,
        val ownerId: String,
        val name: String,
        val description: String,
        val inviteCode: String
    ) : SyncEvent()

    @Serializable @SerialName("group_join")
    data class GroupJoin(override val key: String, val code: String) : SyncEvent()

    @Serializable @SerialName("group_leave")
    data class GroupLeave(override val key: String, val groupId: String, val userId: String) : SyncEvent()

    @Serializable @SerialName("friend_add")
    data class FriendAdd(override val key: String, val userId: String, val friendId: String) : SyncEvent()

    @Serializable @SerialName("friend_remove")
    data class FriendRemove(override val key: String, val userId: String, val friendId: String) : SyncEvent()
}
