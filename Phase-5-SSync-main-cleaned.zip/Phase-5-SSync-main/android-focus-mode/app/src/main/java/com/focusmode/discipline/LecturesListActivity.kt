package com.focusmode.discipline

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * Lecture list for a chapter.
 *
 * Each lecture row shows:
 *   - Lecture number / subchapter name (if provided via intent extra "subchapter_names")
 *   - Status dot + label (pending / in-progress / completed)
 *   - "Mark Done" button (manual completion — bypasses the timer)
 *   - "+ Add to To-Do" button
 *   - "Play" button (opens FocusTimerActivity with blocking engine)
 *
 * Revision automation: when the LAST pending lecture is marked completed,
 * SyllabusPrefs.updateLectureStatus auto-marks the parent chapter as completed
 * and schedules 1/3/7/21-day revisions.
 */
class LecturesListActivity : AppCompatActivity() {

    private lateinit var container: LinearLayout
    private var chapterId: String = ""
    private var chapterName: String = ""
    private var subchapterNames: List<String> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lectures_list)

        chapterId = intent.getStringExtra("chapter_id") ?: ""
        chapterName = intent.getStringExtra("chapter_name") ?: ""
        subchapterNames = intent.getStringArrayListExtra("subchapter_names") ?: arrayListOf()
        findViewById<TextView>(R.id.lecturesTitle).text = chapterName
        container = findViewById(R.id.lecturesContainer)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        container.removeAllViews()
        val lectures = SyllabusPrefs.getLecturesForChapter(this, chapterId)
        if (lectures.isEmpty()) {
            val empty = TextView(this).apply {
                text = getString(R.string.syllabus_no_lectures)
                setTextColor(getColor(R.color.text_muted))
                setPadding(0, 40, 0, 0)
            }
            container.addView(empty)
            return
        }
        val inflater = LayoutInflater.from(this)
        lectures.forEach { lec ->
            val row = inflater.inflate(R.layout.item_lecture, container, false)
            // If we have subchapter names, show them; otherwise fall back to "Lecture N".
            val nameLabel = subchapterNames.getOrNull(lec.number - 1)
            val titleText = if (!nameLabel.isNullOrBlank()) nameLabel
                             else getString(R.string.lec_number_fmt, lec.number)
            row.findViewById<TextView>(R.id.lectureNumber).text = titleText

            val status = row.findViewById<TextView>(R.id.lectureStatus)
            val dot = row.findViewById<View>(R.id.lectureDot)
            when (lec.status) {
                "completed" -> {
                    status.text = getString(R.string.status_completed); status.setTextColor(0xFF4CAF50.toInt())
                    dot.setBackgroundResource(R.drawable.dot_green)
                }
                "in-progress" -> {
                    status.text = getString(R.string.status_in_progress); status.setTextColor(0xFFFFC107.toInt())
                    dot.setBackgroundResource(R.drawable.dot_yellow)
                }
                else -> {
                    status.text = getString(R.string.status_pending); status.setTextColor(0xFFF44336.toInt())
                    dot.setBackgroundResource(R.drawable.dot_red)
                }
            }

            // Mark Done (manual)
            val markDoneBtn = row.findViewById<Button>(R.id.markDoneBtn)
            if (lec.status == "completed") {
                markDoneBtn.visibility = View.GONE
            } else {
                markDoneBtn.visibility = View.VISIBLE
                markDoneBtn.setOnClickListener {
                    SyllabusPrefs.updateLectureStatus(this, lec.id, "completed", lec.durationMs)
                    // When all lectures in this chapter are complete, the helper above auto-schedules
                    // revisions via scheduleRevisionsForChapter.
                    Toast.makeText(this, R.string.lecture_marked_done, Toast.LENGTH_SHORT).show()
                    render()
                }
            }

            row.findViewById<Button>(R.id.addTodoBtn).setOnClickListener {
                TaskPrefs.addTask(this, "$chapterName — $titleText")
                Toast.makeText(this, R.string.syllabus_added_to_todo, Toast.LENGTH_SHORT).show()
            }

            row.findViewById<Button>(R.id.playBtn).setOnClickListener {
                if (lec.status == "completed") {
                    Toast.makeText(this, R.string.status_completed, Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                promptDurationAndStart(lec, titleText)
            }

            container.addView(row)
        }
    }

    private fun promptDurationAndStart(lecture: Lecture, lectureLabel: String) {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = getString(R.string.sy_duration_hint)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.sy_enter_duration)
            .setView(input)
            .setPositiveButton(R.string.sy_start) { _, _ ->
                val mins = input.text.toString().toIntOrNull() ?: 0
                if (mins <= 0) {
                    Toast.makeText(this, R.string.sy_invalid_duration, Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                SyllabusPrefs.updateLectureStatus(this, lecture.id, "in-progress", mins.toLong() * 60_000L)
                val intent = Intent(this, FocusTimerActivity::class.java).apply {
                    putExtra("duration_ms", mins.toLong() * 60_000L)
                    putExtra("label", "$chapterName — $lectureLabel")
                    putExtra("chapter_id", chapterId)
                    putExtra("lecture_id", lecture.id)
                    putExtra("is_lecture", true)
                }
                startActivity(intent)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
