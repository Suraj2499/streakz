package com.focusmode.discipline

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Local storage for the Syllabus module:
 *  - chapters:    JSON array, keyed by `id` (subjectId scoping via `subjectId` field)
 *  - lectures:    JSON array, keyed by `id` (chapterId scoping)
 *  - revisions:   JSON array — scheduled on chapter completion (+1/+3/+7/+21 days)
 *
 * Kept in its own preference file to remain isolated from blocking / tasks / user prefs.
 */
object SyllabusPrefs {
    private const val FILE = "syllabus_prefs"
    private const val KEY_CHAPTERS = "syllabus_chapters_v1"
    private const val KEY_LECTURES = "syllabus_lectures_v1"
    private const val KEY_REVISIONS = "syllabus_revisions_v1"
    private val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private fun sp(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ---------- Chapters ----------

    fun getAllChapters(ctx: Context): List<Chapter> {
        val raw = sp(ctx).getString(KEY_CHAPTERS, "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Chapter(
                id = o.optString("id"),
                subjectId = o.optString("subjectId"),
                name = o.optString("name"),
                status = o.optString("status", "pending"),
                totalLectures = o.optInt("totalLectures", 0)
            )
        }
    }

    private fun saveChapters(ctx: Context, chapters: List<Chapter>) {
        val arr = JSONArray()
        chapters.forEach {
            val o = JSONObject()
            o.put("id", it.id); o.put("subjectId", it.subjectId); o.put("name", it.name)
            o.put("status", it.status); o.put("totalLectures", it.totalLectures)
            arr.put(o)
        }
        sp(ctx).edit().putString(KEY_CHAPTERS, arr.toString()).apply()
    }

    /** Ensure chapters exist for this subject; seed once if none. */
    fun getChaptersForSubject(ctx: Context, subject: Subject): List<Chapter> {
        val all = getAllChapters(ctx)
        return all.filter { it.subjectId == subject.id }
    }

    /**
     * Merge catalog chapters with persisted state. Any chapter not yet in prefs is
     * inserted with status "pending" (preserving deterministic IDs), and any existing
     * one is returned with its saved status/totalLectures preserved.
     */
    fun getChaptersForContext(
        ctx: Context,
        course: String,
        level: String,
        group: String?,
        subject: String,
        subsubject: String?
    ): List<Chapter> {
        val catalog = SyllabusCatalog.getChaptersForContext(ctx, course, level, group, subject, subsubject)
        if (catalog.isEmpty()) return emptyList()
        val all = getAllChapters(ctx).toMutableList()
        val existingIds = all.map { it.id }.toHashSet()
        val newOnes = catalog.filter { it.id !in existingIds }
        if (newOnes.isNotEmpty()) {
            saveChapters(ctx, all + newOnes)
        }
        // Return in catalog order (authoritative sequence from JSON)
        val fresh = getAllChapters(ctx).associateBy { it.id }
        return catalog.map { c -> fresh[c.id] ?: c }
    }

    fun getChapter(ctx: Context, chapterId: String): Chapter? =
        getAllChapters(ctx).firstOrNull { it.id == chapterId }

    fun updateChapterStatus(ctx: Context, chapterId: String, status: String) {
        val all = getAllChapters(ctx).toMutableList()
        val i = all.indexOfFirst { it.id == chapterId }
        if (i < 0) return
        all[i] = all[i].copy(status = status)
        saveChapters(ctx, all)
        if (status == "completed") {
            runCatching { com.focusmode.discipline.sync.SyncManager.syncProgressFromLocal(ctx) }
        }
    }

    fun setChapterLectureCount(ctx: Context, chapterId: String, count: Int) {
        val all = getAllChapters(ctx).toMutableList()
        val i = all.indexOfFirst { it.id == chapterId }
        if (i < 0) return
        all[i] = all[i].copy(totalLectures = count)
        saveChapters(ctx, all)
    }

    // ---------- Lectures ----------

    fun getAllLectures(ctx: Context): List<Lecture> {
        val raw = sp(ctx).getString(KEY_LECTURES, "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Lecture(
                id = o.optString("id"),
                chapterId = o.optString("chapterId"),
                number = o.optInt("number"),
                status = o.optString("status", "pending"),
                durationMs = o.optLong("durationMs", 0L)
            )
        }
    }

    private fun saveLectures(ctx: Context, lectures: List<Lecture>) {
        val arr = JSONArray()
        lectures.forEach {
            val o = JSONObject()
            o.put("id", it.id); o.put("chapterId", it.chapterId); o.put("number", it.number)
            o.put("status", it.status); o.put("durationMs", it.durationMs)
            arr.put(o)
        }
        sp(ctx).edit().putString(KEY_LECTURES, arr.toString()).apply()
    }

    fun getLecturesForChapter(ctx: Context, chapterId: String): List<Lecture> =
        getAllLectures(ctx).filter { it.chapterId == chapterId }.sortedBy { it.number }

    /** Idempotent: generates Lecture 1..N for chapter. If some exist, preserves their state; trims/extends to N. */
    fun generateLecturesForChapter(ctx: Context, chapterId: String, count: Int) {
        if (count <= 0) return
        val all = getAllLectures(ctx).toMutableList()
        val existing = all.filter { it.chapterId == chapterId }.associateBy { it.number }
        val withoutThis = all.filter { it.chapterId != chapterId }.toMutableList()
        val fresh = (1..count).map { n ->
            existing[n] ?: Lecture(
                id = UUID.randomUUID().toString(),
                chapterId = chapterId,
                number = n,
                status = "pending",
                durationMs = 0L
            )
        }
        saveLectures(ctx, withoutThis + fresh)
        setChapterLectureCount(ctx, chapterId, count)
    }

    /**
     * Ensure lectures exist for a chapter whose subchapters come from the syllabus JSON.
     * Lecture numbers map 1-indexed to subchapter names. Re-running this is idempotent:
     * existing statuses are preserved; new subchapters are appended as pending.
     *
     * Returns the lecture names aligned with each lecture in order.
     */
    fun ensureLecturesFromSubchapters(
        ctx: Context, chapterId: String, subchapterNames: List<String>
    ): List<String> {
        if (subchapterNames.isEmpty()) return emptyList()
        generateLecturesForChapter(ctx, chapterId, subchapterNames.size)
        return subchapterNames
    }

    fun updateLectureStatus(ctx: Context, lectureId: String, status: String, durationMs: Long? = null) {
        val all = getAllLectures(ctx).toMutableList()
        val i = all.indexOfFirst { it.id == lectureId }
        if (i < 0) return
        all[i] = all[i].copy(
            status = status,
            durationMs = durationMs ?: all[i].durationMs
        )
        saveLectures(ctx, all)
        if (status == "completed") {
            runCatching { com.focusmode.discipline.sync.SyncManager.syncProgressFromLocal(ctx) }
        }
        // If all lectures for this chapter are complete, mark chapter complete and schedule revisions.
        val chapId = all[i].chapterId
        val siblings = all.filter { it.chapterId == chapId }
        if (siblings.isNotEmpty() && siblings.all { it.status == "completed" }) {
            updateChapterStatus(ctx, chapId, "completed")
            scheduleRevisionsForChapter(ctx, chapId)
        }
    }

    // ---------- Revisions ----------

    fun getAllRevisions(ctx: Context): List<RevisionItem> {
        val raw = sp(ctx).getString(KEY_REVISIONS, "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            RevisionItem(
                id = o.optString("id"),
                chapterId = o.optString("chapterId"),
                chapterName = o.optString("chapterName"),
                scheduledDate = o.optString("scheduledDate")
            )
        }
    }

    private fun saveRevisions(ctx: Context, items: List<RevisionItem>) {
        val arr = JSONArray()
        items.forEach {
            val o = JSONObject()
            o.put("id", it.id); o.put("chapterId", it.chapterId)
            o.put("chapterName", it.chapterName); o.put("scheduledDate", it.scheduledDate)
            arr.put(o)
        }
        sp(ctx).edit().putString(KEY_REVISIONS, arr.toString()).apply()
    }

    fun scheduleRevisionsForChapter(ctx: Context, chapterId: String) {
        val chap = getChapter(ctx, chapterId) ?: return
        val all = getAllRevisions(ctx).toMutableList()
        // Avoid duplicate scheduling: remove any existing revisions for this chapter first.
        all.removeAll { it.chapterId == chapterId }
        val offsets = intArrayOf(1, 3, 7, 21)
        offsets.forEach { d ->
            val c = Calendar.getInstance()
            c.add(Calendar.DAY_OF_MONTH, d)
            all.add(
                RevisionItem(
                    id = UUID.randomUUID().toString(),
                    chapterId = chap.id,
                    chapterName = chap.name,
                    scheduledDate = dateFmt.format(c.time)
                )
            )
        }
        saveRevisions(ctx, all)
    }

    /** Revisions due today or earlier (for Dashboard Revisions tab). */
    fun getRevisionsDue(ctx: Context): List<RevisionItem> {
        val today = dateFmt.format(Date())
        return getAllRevisions(ctx).filter { it.scheduledDate <= today }
    }

    /** Remove one revision by id (used when user marks a revision as done from the dashboard). */
    fun completeRevision(ctx: Context, revisionId: String) {
        val all = getAllRevisions(ctx).toMutableList()
        val changed = all.removeAll { it.id == revisionId }
        if (changed) saveRevisions(ctx, all)
    }

    // ---------- Analytics helpers ----------

    /**
     * Overall syllabus progress as a 0-100 integer percentage across ALL chapters
     * the user has touched (including seed chapters). Returns 0 if no chapters yet.
     */
    fun getOverallProgressPercent(ctx: Context): Int {
        val all = getAllChapters(ctx)
        if (all.isEmpty()) return 0
        val done = all.count { it.status == "completed" }
        return ((done.toDouble() / all.size) * 100.0).toInt().coerceIn(0, 100)
    }
}
