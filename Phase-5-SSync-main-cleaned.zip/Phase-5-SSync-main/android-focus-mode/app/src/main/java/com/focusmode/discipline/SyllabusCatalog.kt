package com.focusmode.discipline

import android.content.Context

/**
 * Thin adapter over SyllabusLoader. Retained for backward compatibility with
 * older callers that still use `getSubjects(course, level)` or pass a Subject
 * into `seedChaptersFor` — new UI routes directly through SyllabusLoader with
 * full context.
 */
object SyllabusCatalog {

    /**
     * Returns subjects for a course/level combo.
     * NOTE: This ignores Group, so it's only accurate for Foundation-level subjects
     * (where there are no groups). For Intermediate/Final, the callers must use
     * SyllabusLoader.getSubjects(course, level, group) directly.
     *
     * Kept so the old Dashboard header snippet keeps compiling. Subject id is
     * deterministic so progress links back to the same chapters.
     */
    @Deprecated("Pass group and use SyllabusLoader directly for post-Foundation levels")
    fun getSubjects(course: String?, level: String?): List<Subject> {
        // This path is only used when we have an application context handy; without
        // one we can't call SyllabusLoader. Return empty; new UI doesn't use this.
        return emptyList()
    }

    fun getSubjects(ctx: Context, course: String, level: String, group: String?): List<Subject> {
        return SyllabusLoader.getSubjects(ctx, course, level, group).map { subjectName ->
            Subject(
                id = SyllabusLoader.subjectId(course, level, group, subjectName, null),
                name = subjectName
            )
        }
    }

    fun getChaptersForContext(
        ctx: Context,
        course: String,
        level: String,
        group: String?,
        subject: String,
        subsubject: String?
    ): List<Chapter> {
        val names = SyllabusLoader.getChapters(ctx, course, level, group, subject, subsubject)
        val subjId = SyllabusLoader.subjectId(course, level, group, subject, subsubject)
        return names.map { chapterName ->
            val id = SyllabusLoader.chapterId(course, level, group, subject, subsubject, chapterName)
            Chapter(
                id = id,
                subjectId = subjId,
                name = chapterName,
                status = "pending",
                totalLectures = SyllabusLoader.getSubchapters(
                    ctx, course, level, group, subject, subsubject, chapterName
                ).size
            )
        }
    }

    /** Back-compat: still used by SyllabusPrefs.getChaptersForSubject — just returns empty. */
    @Deprecated("No longer seeds — use getChaptersForContext instead")
    fun seedChaptersFor(subject: Subject): List<Chapter> = emptyList()
}
