package com.focusmode.discipline.sync

import android.content.Context
import android.content.SharedPreferences
import kotlinx.serialization.json.Json

/**
 * Persistent FIFO queue for SyncEvents. Backed by a single JSON array in
 * SharedPreferences so it survives process death.
 *
 * Concurrency: all mutators are synchronized. Size is bounded loosely —
 * if the queue grows beyond 500, the oldest events are dropped (should never
 * happen in normal use, but guards against runaway bugs).
 */
object SyncQueue {
    private const val FILE = "sync_queue"
    private const val KEY_EVENTS = "events_v1"
    private const val MAX_SIZE = 500

    internal val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val lock = Any()

    private fun sp(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun enqueue(ctx: Context, event: SyncEvent) {
        synchronized(lock) {
            val list = loadRaw(ctx).toMutableList()
            // Collapse duplicates by idempotency key.
            list.removeAll { it.key == event.key }
            list.add(event)
            while (list.size > MAX_SIZE) list.removeAt(0)
            save(ctx, list)
        }
    }

    fun snapshot(ctx: Context): List<SyncEvent> = synchronized(lock) { loadRaw(ctx) }

    fun removeByKey(ctx: Context, key: String) {
        synchronized(lock) {
            val list = loadRaw(ctx).toMutableList()
            if (list.removeAll { it.key == key }) save(ctx, list)
        }
    }

    fun clear(ctx: Context) {
        synchronized(lock) { sp(ctx).edit().remove(KEY_EVENTS).apply() }
    }

    fun size(ctx: Context): Int = synchronized(lock) { loadRaw(ctx).size }

    private fun loadRaw(ctx: Context): List<SyncEvent> {
        val raw = sp(ctx).getString(KEY_EVENTS, null) ?: return emptyList()
        return try {
            json.decodeFromString(
                kotlinx.serialization.builtins.ListSerializer(SyncEvent.serializer()),
                raw
            )
        } catch (_: Throwable) {
            // Corrupt — reset rather than crash.
            sp(ctx).edit().remove(KEY_EVENTS).apply()
            emptyList()
        }
    }

    private fun save(ctx: Context, list: List<SyncEvent>) {
        val encoded = json.encodeToString(
            kotlinx.serialization.builtins.ListSerializer(SyncEvent.serializer()),
            list
        )
        sp(ctx).edit().putString(KEY_EVENTS, encoded).apply()
    }
}
