package com.focusmode.discipline.sync

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.focusmode.discipline.UserPrefs
import com.focusmode.discipline.net.AuthManager
import com.focusmode.discipline.net.dto.ProgressDto
import com.focusmode.discipline.net.dto.UserDto
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * High-level API used by the rest of the app to schedule sync work.
 *
 * Rules:
 *   - Every public enqueue*() both writes an event AND triggers a sync attempt.
 *   - All writes are idempotent; duplicates are collapsed by idempotency key.
 *   - Sync requires network; WorkManager handles retries with exponential backoff.
 */
object SyncManager {

    private const val WORK_NAME = "sync_supabase"

    // -------- Event builders --------

    fun enqueueUserUpsert(ctx: Context, user: UserDto) {
        SyncQueue.enqueue(ctx, SyncEvent.UserUpsert(key = "user:${user.id}", user = user))
        triggerSyncNow(ctx)
    }

    fun enqueueProgressUpsert(ctx: Context, progress: ProgressDto) {
        // One-key-per-user: repeated updates coalesce to the latest snapshot.
        SyncQueue.enqueue(ctx, SyncEvent.ProgressUpsert(key = "progress:${progress.userId}", progress = progress))
        triggerSyncNow(ctx)
    }

    fun enqueueGroupCreate(ctx: Context, id: String, ownerId: String, name: String, description: String, inviteCode: String) {
        SyncQueue.enqueue(ctx, SyncEvent.GroupCreate(
            key = "group_create:$id", id = id, ownerId = ownerId,
            name = name, description = description, inviteCode = inviteCode
        ))
        triggerSyncNow(ctx)
    }

    fun enqueueGroupJoin(ctx: Context, code: String) {
        SyncQueue.enqueue(ctx, SyncEvent.GroupJoin(key = "group_join:${code.uppercase()}:${UUID.randomUUID()}", code = code.uppercase()))
        triggerSyncNow(ctx)
    }

    fun enqueueGroupLeave(ctx: Context, groupId: String, userId: String) {
        SyncQueue.enqueue(ctx, SyncEvent.GroupLeave(key = "group_leave:$groupId:$userId", groupId = groupId, userId = userId))
        triggerSyncNow(ctx)
    }

    fun enqueueFriendAdd(ctx: Context, userId: String, friendId: String) {
        SyncQueue.enqueue(ctx, SyncEvent.FriendAdd(key = "friend_add:$userId:$friendId", userId = userId, friendId = friendId))
        triggerSyncNow(ctx)
    }

    fun enqueueFriendRemove(ctx: Context, userId: String, friendId: String) {
        SyncQueue.enqueue(ctx, SyncEvent.FriendRemove(key = "friend_remove:$userId:$friendId", userId = userId, friendId = friendId))
        triggerSyncNow(ctx)
    }

    // -------- WorkManager --------

    fun triggerSyncNow(ctx: Context) {
        val req = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(
                Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
            )
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(ctx.applicationContext)
            .enqueueUniqueWork(WORK_NAME, ExistingWorkPolicy.APPEND_OR_REPLACE, req)
    }

    // -------- Convenience helpers that build DTOs from local state --------

    /**
     * Build a ProgressDto from local prefs and enqueue an upsert.
     * Safe to call on every progress event; collapses via idempotency key.
     */
    fun syncProgressFromLocal(ctx: Context) {
        val uid = AuthManager.currentUserId() ?: return
        val minutes = (com.focusmode.discipline.TaskPrefs.getTotalFocusMs(ctx) / 60_000L).toInt()
        val chapters = runCatching {
            com.focusmode.discipline.SyllabusPrefs.getAllChapters(ctx).count { it.status == "completed" }
        }.getOrDefault(0)
        val lectures = runCatching {
            com.focusmode.discipline.SyllabusPrefs.getAllLectures(ctx).count { it.status == "completed" }
        }.getOrDefault(0)
        val revisions = runCatching {
            com.focusmode.discipline.SyllabusPrefs.getAllRevisions(ctx).size // placeholder — actual count tracked differently
        }.getOrDefault(0)
        val streak = com.focusmode.discipline.TaskPrefs.getStreak(ctx)
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        enqueueProgressUpsert(ctx, ProgressDto(
            userId = uid,
            totalFocusMinutes = minutes,
            chaptersCompleted = chapters,
            lecturesCompleted = lectures,
            revisionsCompleted = revisions,
            streakDays = streak,
            lastActiveDate = today
        ))
    }

    /** Rebuild a UserDto from local profile + enqueue upsert. */
    fun syncProfileFromLocal(ctx: Context) {
        val uid = AuthManager.currentUserId() ?: return
        val p = UserPrefs.getProfile(ctx)
        val mappedLevel = p.level?.let { lvl ->
            p.course?.let { c -> com.focusmode.discipline.SyllabusLoader.displayLevel(c, lvl) } ?: lvl
        }
        val attempt = p.examMonth?.let { raw ->
            if (raw.length == 7 && raw[2] == '/') {
                val mm = raw.substring(0,2).toIntOrNull() ?: return@let null
                val yyyy = raw.substring(3,7)
                arrayOf("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")
                    .getOrNull(mm - 1)?.let { "$it $yyyy" }
            } else null
        }
        enqueueUserUpsert(ctx, UserDto(
            id = uid,
            name = p.name.ifBlank { p.email.substringBefore("@") },
            course = p.course,
            level = mappedLevel,
            attempt = attempt,
            avatarLetter = (p.name.ifBlank { p.email }).firstOrNull()?.uppercase()
        ))
    }
}
