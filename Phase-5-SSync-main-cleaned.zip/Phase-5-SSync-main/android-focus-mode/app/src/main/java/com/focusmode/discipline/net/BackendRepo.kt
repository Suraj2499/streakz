package com.focusmode.discipline.net

import com.focusmode.discipline.net.dto.FriendDto
import com.focusmode.discipline.net.dto.GroupDto
import com.focusmode.discipline.net.dto.GroupLbArgs
import com.focusmode.discipline.net.dto.GroupMemberDto
import com.focusmode.discipline.net.dto.JoinGroupArgs
import com.focusmode.discipline.net.dto.LeaderboardRowDto
import com.focusmode.discipline.net.dto.ProgressDto
import com.focusmode.discipline.net.dto.PublicLbArgs
import com.focusmode.discipline.net.dto.UserDto
import io.github.jan.supabase.postgrest.query.Columns
import io.github.jan.supabase.postgrest.*
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Narrow facade over Supabase Postgrest for the app's domain.
 *
 * All reads return Result<T>; callers decide how to fall back when offline.
 * Writes are idempotent (upsert / on conflict do nothing) so the SyncWorker can
 * safely retry.
 */
object BackendRepo {

    private val client get() = Supabase.client

    // ---------- Users ----------

    suspend fun upsertUser(dto: UserDto): Result<Unit> = io {
        client.postgrest.from("users").upsert(dto)
    }

    suspend fun fetchUser(userId: String): Result<UserDto?> = io {
        client.postgrest.from("users").select { filter { eq("id", userId) } }.decodeSingleOrNull<UserDto>()
    }

    // ---------- Progress ----------

    /**
     * Upsert progress with conflict-resolving GREATEST() semantics. We upload what
     * we have; if the server has a larger value (from another device), a follow-up
     * fetch reconciles.
     */
    suspend fun upsertProgress(dto: ProgressDto): Result<Unit> = io {
        client.postgrest.from("progress").upsert(dto)
    }

    suspend fun fetchProgress(userId: String): Result<ProgressDto?> = io {
        client.postgrest.from("progress").select {
            filter { eq("user_id", userId) }
        }.decodeSingleOrNull<ProgressDto>()
    }

    // ---------- Leaderboard ----------

    suspend fun getPublicLeaderboard(course: String, level: String, attempt: String): Result<List<LeaderboardRowDto>> = io {
        client.postgrest.rpc("get_public_leaderboard", PublicLbArgs(course, level, attempt))
            .decodeList<LeaderboardRowDto>()
    }

    suspend fun getGroupLeaderboard(groupId: String): Result<List<LeaderboardRowDto>> = io {
        client.postgrest.rpc("get_group_leaderboard", GroupLbArgs(groupId))
            .decodeList<LeaderboardRowDto>()
    }

    // ---------- Groups ----------

    suspend fun createGroup(dto: GroupDto): Result<GroupDto> = io {
        val inserted = client.postgrest.from("groups").insert(dto) {
            select()
        }.decodeSingle<GroupDto>()
        // Also insert the owner as a member. Idempotent.
        runCatching {
            client.postgrest.from("group_members").insert(
                GroupMemberDto(groupId = inserted.id, userId = dto.ownerId ?: "")
            )
        }
        inserted
    }

    suspend fun joinGroupByCode(code: String): Result<String?> = io {
        client.postgrest.rpc("join_group_by_code", JoinGroupArgs(code.uppercase()))
            .decodeSingleOrNull<String>()
    }

    suspend fun leaveGroup(groupId: String, userId: String): Result<Unit> = io {
        client.postgrest.from("group_members").delete {
            filter { eq("group_id", groupId); eq("user_id", userId) }
        }
    }

    suspend fun fetchMyGroups(userId: String): Result<List<GroupDto>> = io {
        // Get group ids the user belongs to first, then fetch group rows.
        val memberRows = client.postgrest.from("group_members").select {
            filter { eq("user_id", userId) }
        }.decodeList<GroupMemberDto>()
        if (memberRows.isEmpty()) return@io emptyList()
        val ids = memberRows.map { it.groupId }
        client.postgrest.from("groups").select {
            filter { isIn("id", ids) }
        }.decodeList<GroupDto>()
    }

    suspend fun fetchGroupMembers(groupId: String): Result<List<UserDto>> = io {
        val memberRows = client.postgrest.from("group_members").select {
            filter { eq("group_id", groupId) }
        }.decodeList<GroupMemberDto>()
        if (memberRows.isEmpty()) return@io emptyList()
        val ids = memberRows.map { it.userId }
        client.postgrest.from("users").select {
            filter { isIn("id", ids) }
        }.decodeList<UserDto>()
    }

    // ---------- Friends ----------

    suspend fun addFriend(userId: String, friendId: String): Result<Unit> = io {
        client.postgrest.from("friends").upsert(FriendDto(userId, friendId))
    }

    suspend fun removeFriend(userId: String, friendId: String): Result<Unit> = io {
        client.postgrest.from("friends").delete {
            filter { eq("user_id", userId); eq("friend_id", friendId) }
        }
    }

    suspend fun fetchFriends(userId: String): Result<List<UserDto>> = io {
        val friendRows = client.postgrest.from("friends").select(Columns.list("friend_id")) {
            filter { eq("user_id", userId) }
        }.decodeList<FriendDto>()
        if (friendRows.isEmpty()) return@io emptyList()
        val ids = friendRows.map { it.friendId }
        client.postgrest.from("users").select {
            filter { isIn("id", ids) }
        }.decodeList<UserDto>()
    }

    // ---------- Helpers ----------

    private suspend inline fun <T> io(crossinline block: suspend () -> T): Result<T> =
        withContext(Dispatchers.IO) {
            try { Result.success(block()) } catch (t: Throwable) { Result.failure(t) }
        }
}
