package com.focusmode.discipline

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

/** Profile tab: shows the signed-in user + logout. */
class ProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val user = UserPrefs.getProfile(this)
        findViewById<TextView>(R.id.profileName).text =
            user.name.ifBlank { getString(R.string.profile_no_name) }
        findViewById<TextView>(R.id.profileEmail).text = user.email
        val course = listOfNotNull(user.course, user.level).filter { it.isNotBlank() }
            .joinToString(" • ")
        findViewById<TextView>(R.id.profileCourse).text =
            if (course.isNotEmpty()) course else getString(R.string.profile_no_course)

        findViewById<Button>(R.id.logoutBtn).setOnClickListener {
            UserPrefs.logout(this)
            startActivity(
                Intent(this, LauncherActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            )
            finish()
        }

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        BottomNavHelper.setup(this, bottomNav, R.id.nav_profile)
    }
}
