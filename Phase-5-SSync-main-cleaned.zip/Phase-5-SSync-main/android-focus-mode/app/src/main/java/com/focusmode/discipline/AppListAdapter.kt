package com.focusmode.discipline

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppListAdapter(private val items: List<AppItem>) :
    RecyclerView.Adapter<AppListAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val label: TextView = v.findViewById(R.id.label)
        val pkg: TextView = v.findViewById(R.id.pkg)
        val check: CheckBox = v.findViewById(R.id.check)
        val row: View = v
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.label.text = item.label
        holder.pkg.text = item.packageName
        holder.check.setOnCheckedChangeListener(null)
        holder.check.isChecked = item.selected
        holder.check.setOnCheckedChangeListener { _, isChecked ->
            item.selected = isChecked
        }
        holder.row.setOnClickListener {
            holder.check.isChecked = !holder.check.isChecked
        }
    }

    override fun getItemCount(): Int = items.size

    fun getSelectedPackages(): Set<String> =
        items.filter { it.selected }.map { it.packageName }.toSet()
}
