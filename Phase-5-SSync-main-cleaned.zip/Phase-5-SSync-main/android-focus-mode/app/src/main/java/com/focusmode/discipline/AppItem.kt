package com.focusmode.discipline

data class AppItem(
    val packageName: String,
    val label: String,
    val isSystem: Boolean,
    var selected: Boolean
)
