package com.focusmode.discipline.net

import android.content.Context
import android.util.Log
import com.focusmode.discipline.UserPrefs
import com.focusmode.discipline.net.dto.UserDto
import com.focusmode.discipline.sync.SyncManager
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Thin wrapper around Supabase auth so the rest of the app doesn't depend on
 * the SDK surface. All calls are suspend / IO-bound.
 */
object AuthManager {

    private const val TAG = "AuthManager"
    private val client get() = Supabase.client

    /** True if we have a cached Supabase session. */
    fun hasSession(): Boolean = client.auth.currentSessionOrNull() != null

    /** The current authenticated user's UUID (or null). */
    fun currentUserId(): String? = client.auth.currentUserOrNull()?.id

    /**
     * Sign up with email/password and create the profile row.
     * Returns Result.success(userId) or Result.failure(Exception).
     */
    suspend fun signUp(ctx: Context, email: String, password: String, name: String): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                client.auth.signUpWith(Email) {
                    this.email = email.trim()
                    this.password = password
                }
                val uid = client.auth.currentUserOrNull()?.id
                if (uid == null) {
                    // Email confirmation is required on this project — signup succeeded but
                    // we have no session yet. Caller should ask the user to verify + log in.
                    return@withContext Result.failure(EmailConfirmationRequired)
                }
                // Persist minimal profile locally.
                UserPrefs.replaceIdentity(ctx, uid, name.trim(), email.trim())
                // Insert users row (upsert idempotent thanks to PK = auth uid).
                val dto = UserDto(id = uid, name = name.trim(), avatarLetter = name.trim().firstOrNull()?.uppercase())
                client.postgrest.from("users").upsert(dto)
                Result.success(uid)
            } catch (t: Throwable) {
                Log.e(TAG, "signUp failed", t); Result.failure(t)
            }
        }

    /** Sentinel exception thrown when signup succeeded but requires email verification. */
    object EmailConfirmationRequired : RuntimeException(
        "Email sent. Please verify your email, then log in."
    )

    suspend fun signIn(ctx: Context, email: String, password: String): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                client.auth.signInWith(Email) {
                    this.email = email.trim()
                    this.password = password
                }
                val uid = client.auth.currentUserOrNull()?.id
                    ?: return@withContext Result.failure(IllegalStateException("Sign-in returned no user."))
                // Pull profile and cache locally so UI is populated offline.
                val existing = runCatching {
                    client.postgrest.from("users").select {
                        filter { eq("id", uid) }
                    }.decodeSingleOrNull<UserDto>()
                }.getOrNull()
                if (existing != null) {
                    UserPrefs.hydrateFromRemote(ctx, uid, existing.name, email.trim(),
                        existing.course, existing.level, existing.attempt)
                } else {
                    // First-login-from-another-device-without-row case — keep local data.
                    UserPrefs.replaceIdentity(ctx, uid, UserPrefs.getProfile(ctx).name.ifBlank { email.substringBefore("@") }, email.trim())
                }
                // Fire a sync so any locally-queued events go out now that we're logged in.
                SyncManager.triggerSyncNow(ctx.applicationContext)
                Result.success(uid)
            } catch (t: Throwable) {
                Log.e(TAG, "signIn failed", t); Result.failure(t)
            }
        }

    suspend fun signOut(ctx: Context): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            client.auth.signOut()
            UserPrefs.logout(ctx)
            Result.success(Unit)
        } catch (t: Throwable) {
            Log.e(TAG, "signOut failed", t); Result.failure(t)
        }
    }
}
