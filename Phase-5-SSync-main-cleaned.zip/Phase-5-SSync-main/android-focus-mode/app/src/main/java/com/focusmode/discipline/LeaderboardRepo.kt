package com.focusmode.discipline

import android.content.Context
import android.content.SharedPreferences
import com.focusmode.discipline.net.AuthManager
import com.focusmode.discipline.net.BackendRepo
import com.focusmode.discipline.net.dto.GroupDto
import com.focusmode.discipline.sync.SyncManager
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.abs

/**
 * Local repository for Leaderboard / Groups / Friends.
 *
 * Backend-ready: all methods are synchronous but the call sites treat them as if
 * they could be suspending. When a backend is added, swap implementations here
 * without touching UI.
 *
 * Persistent storage (SharedPreferences file `leader_prefs`):
 *   - `groups_v1`  : JSON array of LeaderGroup (user-created + joined)
 *   - `friends_v1` : JSON array of Friend
 *
 * Mock data (in-memory only):
 *   - 12 seed users across the three courses / levels / attempts.
 *   - Score for each seed user is deterministic (hash of user id) so it
 *     doesn't flicker across launches.
 *   - The current user's score is computed from real focus time + completed
 *     chapters, so the UI feels tied to actual progress.
 */
object LeaderboardRepo {

    private const val FILE = "leader_prefs"
    private const val KEY_GROUPS = "groups_v1"
    private const val KEY_FRIENDS = "friends_v1"
    private const val KEY_USER_CACHE = "user_cache_v1"   // id -> JSON(name, course, level, avatarLetter)

    private fun sp(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ------------ Mock users ------------

    private val mockUsers: List<LeaderUser> = listOf(
        LeaderUser("u1",  "Aarav Shah",      "CA",  "Intermediate", "May 2026"),
        LeaderUser("u2",  "Riya Mehta",      "CA",  "Intermediate", "May 2026"),
        LeaderUser("u3",  "Kabir Singh",     "CA",  "Intermediate", "May 2026"),
        LeaderUser("u4",  "Ananya Verma",    "CA",  "Intermediate", "May 2026"),
        LeaderUser("u5",  "Vivaan Gupta",    "CA",  "Final",        "Nov 2026"),
        LeaderUser("u6",  "Ishita Rao",      "CA",  "Final",        "Nov 2026"),
        LeaderUser("u7",  "Aditya Joshi",    "CA",  "Foundation",   "Sep 2026"),
        LeaderUser("u8",  "Diya Nair",       "CS",  "Executive",    "Dec 2026"),
        LeaderUser("u9",  "Rohan Iyer",      "CS",  "Executive",    "Dec 2026"),
        LeaderUser("u10", "Kavya Reddy",     "CS",  "Professional", "Jun 2026"),
        LeaderUser("u11", "Dhruv Kapoor",    "CMA", "Intermediate", "Jun 2026"),
        LeaderUser("u12", "Saanvi Pillai",   "CMA", "Intermediate", "Jun 2026")
    )

    private fun mockScoreFor(userId: String): Int {
        // Deterministic 200..1800
        val h = abs(userId.hashCode())
        return 200 + (h % 1601)
    }

    // ------------ Current user (live data) ------------

    /** Compose a LeaderUser from the local profile. */
    fun getCurrentUser(ctx: Context): LeaderUser {
        val p = UserPrefs.getProfile(ctx)
        val course = p.course.orEmpty().ifBlank { "CA" }
        val level = p.level.orEmpty().let {
            // Map internal tag to display level (Executive/Professional for CS, etc.)
            if (it.isBlank()) "Intermediate" else SyllabusLoader.displayLevel(course, it)
        }
        val attempt = examMonthToLabel(p.examMonth)
        val name = p.name.ifBlank { "You" }
        val id = p.userId.ifBlank { "me" }
        return LeaderUser(id, name, course, level, attempt)
    }

    /** Current user's live score = total focus minutes + 50*completed chapters. */
    fun getCurrentUserScore(ctx: Context): Int {
        val minutes = (TaskPrefs.getTotalFocusMs(ctx) / 60_000L).toInt()
        val chapters = try { SyllabusPrefs.getAllChapters(ctx).count { it.status == "completed" } }
                       catch (_: Throwable) { 0 }
        return minutes + chapters * 50
    }

    private fun examMonthToLabel(raw: String?): String {
        if (raw == null || raw.length != 7 || raw[2] != '/') return "TBD"
        val mm = raw.substring(0, 2).toIntOrNull() ?: return "TBD"
        val yyyy = raw.substring(3, 7)
        val months = arrayOf("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")
        val name = months.getOrNull(mm - 1) ?: return "TBD"
        return "$name $yyyy"
    }

    // ------------ Public leaderboard ------------

    /** Group label like "CA Intermediate · May 2026". */
    fun getPublicGroupLabel(ctx: Context): String {
        val me = getCurrentUser(ctx)
        return "${me.course} ${me.level} · ${me.attempt}"
    }

    /** Public leaderboard = mock users in the same (course, level, attempt) + the current user. */
    fun getPublicLeaderboard(ctx: Context): List<LeaderboardEntry> {
        val me = getCurrentUser(ctx)
        val myScore = getCurrentUserScore(ctx)
        val peers = mockUsers.filter {
            it.course.equals(me.course, true) &&
                it.level.equals(me.level, true) &&
                it.attempt.equals(me.attempt, true)
        }
        val rows = peers.map { u ->
            Triple(u.id, u.name, mockScoreFor(u.id))
        }.toMutableList()
        rows.add(Triple(me.id, me.name, myScore))
        return rankRows(rows, me.id)
    }

    // ------------ Groups ------------

    fun getMyGroups(ctx: Context): List<LeaderGroup> {
        val raw = sp(ctx).getString(KEY_GROUPS, "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val members = mutableListOf<String>()
            o.optJSONArray("memberIds")?.let { mi ->
                for (j in 0 until mi.length()) members.add(mi.optString(j))
            }
            LeaderGroup(
                id = o.optString("id"),
                name = o.optString("name"),
                description = o.optString("description"),
                inviteCode = o.optString("inviteCode"),
                memberIds = members,
                ownerId = o.optString("ownerId"),
                createdAt = o.optLong("createdAt", 0L)
            )
        }
    }

    private fun saveGroups(ctx: Context, groups: List<LeaderGroup>) {
        val arr = JSONArray()
        groups.forEach {
            val o = JSONObject()
            o.put("id", it.id); o.put("name", it.name); o.put("description", it.description)
            o.put("inviteCode", it.inviteCode); o.put("ownerId", it.ownerId)
            o.put("createdAt", it.createdAt)
            val mi = JSONArray(); it.memberIds.forEach { id -> mi.put(id) }
            o.put("memberIds", mi)
            arr.put(o)
        }
        sp(ctx).edit().putString(KEY_GROUPS, arr.toString()).apply()
    }

    fun getGroup(ctx: Context, groupId: String): LeaderGroup? =
        getMyGroups(ctx).firstOrNull { it.id == groupId }

    fun createGroup(ctx: Context, name: String, description: String): LeaderGroup {
        // Synchronous local-only path (offline or not logged in).
        // NOTE: when logged in, prefer createGroupSync(ctx, ...) which goes server-first.
        val me = getCurrentUser(ctx)
        val group = LeaderGroup(
            id = "g_" + UUID.randomUUID().toString().take(8),
            name = name.trim().ifEmpty { "My Group" },
            description = description.trim(),
            inviteCode = newInviteCode(),
            memberIds = listOf(me.id),
            ownerId = me.id,
            createdAt = System.currentTimeMillis()
        )
        saveGroups(ctx, getMyGroups(ctx) + group)
        val serverUid = AuthManager.currentUserId()
        if (serverUid != null) {
            SyncManager.enqueueGroupCreate(
                ctx, id = group.id, ownerId = serverUid,
                name = group.name, description = group.description, inviteCode = group.inviteCode
            )
        }
        return group
    }

    /**
     * Server-first group creation. Returns a LeaderGroup whose id MATCHES the server's
     * groups.id — guarantees that a peer joining via invite code resolves to the same row.
     *
     * If the user isn't logged in, falls back to the local-only path.
     */
    suspend fun createGroupSync(ctx: Context, name: String, description: String): LeaderGroup {
        val serverUid = AuthManager.currentUserId()
            ?: return createGroup(ctx, name, description)
        val groupId = UUID.randomUUID().toString()
        val inviteCode = newInviteCode()
        val dto = GroupDto(
            id = groupId,
            name = name.trim().ifEmpty { "My Group" },
            description = description.trim(),
            inviteCode = inviteCode,
            ownerId = serverUid
        )
        val serverGroup = BackendRepo.createGroup(dto).getOrNull()
        if (serverGroup == null) {
            // Couldn't reach server — fall back to local-first + queue a retry.
            return createGroup(ctx, name, description)
        }
        val group = LeaderGroup(
            id = serverGroup.id,
            name = serverGroup.name,
            description = serverGroup.description,
            inviteCode = serverGroup.inviteCode,
            memberIds = listOf(serverUid),
            ownerId = serverUid,
            createdAt = System.currentTimeMillis()
        )
        saveGroups(ctx, getMyGroups(ctx) + group)
        return group
    }

    /**
     * Legacy synchronous join — kept for backward compatibility.
     * When logged in, prefer joinGroupSync(ctx, code) which fetches the authoritative group.
     */
    fun joinGroup(ctx: Context, rawCode: String): LeaderGroup? {
        val code = rawCode.trim().uppercase()
        if (code.isBlank()) return null
        val me = getCurrentUser(ctx)
        val existing = getMyGroups(ctx).firstOrNull { it.inviteCode == code }
        if (existing != null) return existing
        val simulated = LeaderGroup(
            id = "g_" + UUID.randomUUID().toString().take(8),
            name = "Group $code",
            description = "Joined via invite code",
            inviteCode = code,
            memberIds = listOf(me.id),
            ownerId = me.id,
            createdAt = System.currentTimeMillis()
        )
        saveGroups(ctx, getMyGroups(ctx) + simulated)
        SyncManager.enqueueGroupJoin(ctx, code)
        return simulated
    }

    /**
     * Server-first join by invite code. Returns a LeaderGroup whose id MATCHES the server's
     * groups.id — so the creator and this joiner share the exact same group record.
     *
     * Returns null when the code doesn't exist on the server.
     * Falls back to local-only + enqueue when offline / not logged in.
     */
    suspend fun joinGroupSync(ctx: Context, rawCode: String): LeaderGroup? {
        val code = rawCode.trim().uppercase()
        if (code.isBlank()) return null
        val serverUid = AuthManager.currentUserId() ?: return joinGroup(ctx, code)

        // 1. Ask server to add us to that group (RPC with security definer).
        val serverGroupId = BackendRepo.joinGroupByCode(code).getOrNull()
            ?: return null   // code doesn't match any group

        // 2. Fetch the group row + members now that we're a member (RLS allows it).
        val allGroups = BackendRepo.fetchMyGroups(serverUid).getOrNull().orEmpty()
        val serverGroup = allGroups.firstOrNull { it.id == serverGroupId } ?: return null
        val memberUsers = BackendRepo.fetchGroupMembers(serverGroupId).getOrNull().orEmpty()
        memberUsers.forEach { cacheUser(ctx, it.id, it.name, it.course, it.level, it.avatarLetter) }

        // 3. Persist locally under the AUTHORITATIVE server id. Drop any stale
        //    local row that used a different id for the same invite code.
        val localGroup = LeaderGroup(
            id = serverGroup.id,
            name = serverGroup.name,
            description = serverGroup.description,
            inviteCode = serverGroup.inviteCode,
            memberIds = memberUsers.map { it.id },
            ownerId = serverGroup.ownerId ?: serverUid,
            createdAt = System.currentTimeMillis()
        )
        val others = getMyGroups(ctx).filter { it.id != localGroup.id && it.inviteCode != code }
        saveGroups(ctx, others + localGroup)
        return localGroup
    }

    /** Replace a single local group record (used by background refreshes). */
    fun replaceGroup(ctx: Context, group: LeaderGroup) {
        val others = getMyGroups(ctx).filter { it.id != group.id }
        saveGroups(ctx, others + group)
    }

    /** Pull a group's authoritative data (row + members) from the server into local cache. */
    suspend fun refreshGroupFromBackend(ctx: Context, groupId: String): LeaderGroup? {
        val uid = AuthManager.currentUserId() ?: return null
        val allGroups = BackendRepo.fetchMyGroups(uid).getOrNull().orEmpty()
        val serverGroup = allGroups.firstOrNull { it.id == groupId } ?: return null
        val members = BackendRepo.fetchGroupMembers(groupId).getOrNull().orEmpty()
        // Cache member user info so getGroupMembers() can render real joiners.
        members.forEach { cacheUser(ctx, it.id, it.name, it.course, it.level, it.avatarLetter) }
        val updated = LeaderGroup(
            id = serverGroup.id,
            name = serverGroup.name,
            description = serverGroup.description,
            inviteCode = serverGroup.inviteCode,
            memberIds = members.map { it.id },
            ownerId = serverGroup.ownerId ?: "",
            createdAt = System.currentTimeMillis()
        )
        replaceGroup(ctx, updated)
        return updated
    }

    // -------- Cached-user helpers (so group/friend UI can render real joiners) --------

    private fun cacheUser(
        ctx: Context, id: String, name: String, course: String?, level: String?, avatar: String?
    ) {
        val sp = sp(ctx)
        val raw = sp.getString(KEY_USER_CACHE, "{}") ?: "{}"
        val obj = try { JSONObject(raw) } catch (_: Exception) { JSONObject() }
        obj.put(id, JSONObject().apply {
            put("name", name)
            put("course", course ?: "")
            put("level", level ?: "")
            put("avatar", avatar ?: LeaderUser.firstLetter(name))
        })
        sp.edit().putString(KEY_USER_CACHE, obj.toString()).apply()
    }

    private fun readCachedUser(ctx: Context, id: String): LeaderUser? {
        val raw = sp(ctx).getString(KEY_USER_CACHE, "{}") ?: "{}"
        val obj = try { JSONObject(raw) } catch (_: Exception) { return null }
        if (!obj.has(id)) return null
        val u = obj.getJSONObject(id)
        return LeaderUser(
            id = id,
            name = u.optString("name"),
            course = u.optString("course"),
            level = u.optString("level"),
            attempt = "",
            avatarLetter = u.optString("avatar", LeaderUser.firstLetter(u.optString("name")))
        )
    }

    fun deleteGroup(ctx: Context, groupId: String) {
        val remaining = getMyGroups(ctx).filter { it.id != groupId }
        saveGroups(ctx, remaining)
        val serverUid = com.focusmode.discipline.net.AuthManager.currentUserId()
        if (serverUid != null) {
            // Best-effort: ask server to remove our membership. If the groupId
            // is the local-only UUID we generated, server will 404 and worker skips.
            com.focusmode.discipline.sync.SyncManager.enqueueGroupLeave(ctx, groupId, serverUid)
        }
    }

    /** Leaderboard for a specific group (current user + members). */
    fun getGroupLeaderboard(ctx: Context, groupId: String): List<LeaderboardEntry> {
        val group = getGroup(ctx, groupId) ?: return emptyList()
        val me = getCurrentUser(ctx)
        val myScore = getCurrentUserScore(ctx)
        val rows = group.memberIds.mapNotNull { uid ->
            if (uid == me.id) Triple(me.id, me.name, myScore)
            else mockUsers.firstOrNull { it.id == uid }?.let { Triple(it.id, it.name, mockScoreFor(it.id)) }
        }.toMutableList()
        // Ensure the current user appears even if memberIds didn't contain them.
        if (rows.none { it.first == me.id }) {
            rows.add(Triple(me.id, me.name, myScore))
        }
        return rankRows(rows, me.id)
    }

    /** Members as LeaderUser objects (for the Members section). */
    fun getGroupMembers(ctx: Context, groupId: String): List<LeaderUser> {
        val group = getGroup(ctx, groupId) ?: return emptyList()
        val me = getCurrentUser(ctx)
        return group.memberIds.mapNotNull { uid ->
            when {
                uid == me.id -> me
                else -> mockUsers.firstOrNull { it.id == uid }
                    ?: readCachedUser(ctx, uid)
            }
        }
    }

    // ------------ Friends ------------

    fun getFriends(ctx: Context): List<Friend> {
        val raw = sp(ctx).getString(KEY_FRIENDS, "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Friend(
                userId = o.optString("userId"),
                name = o.optString("name"),
                avatarLetter = o.optString("avatarLetter"),
                course = o.optString("course"),
                level = o.optString("level")
            )
        }
    }

    private fun saveFriends(ctx: Context, friends: List<Friend>) {
        val arr = JSONArray()
        friends.forEach {
            val o = JSONObject()
            o.put("userId", it.userId); o.put("name", it.name); o.put("avatarLetter", it.avatarLetter)
            o.put("course", it.course); o.put("level", it.level)
            arr.put(o)
        }
        sp(ctx).edit().putString(KEY_FRIENDS, arr.toString()).apply()
    }

    /** Mock search across seed users. Query = substring match on name (case-insensitive). */
    fun searchUsers(query: String): List<LeaderUser> {
        val q = query.trim().lowercase()
        if (q.isBlank()) return emptyList()
        return mockUsers.filter { it.name.lowercase().contains(q) }.take(8)
    }

    fun addFriend(ctx: Context, user: LeaderUser): Boolean {
        val cur = getFriends(ctx).toMutableList()
        if (cur.any { it.userId == user.id }) return false
        cur.add(Friend(user.id, user.name, user.avatarLetter, user.course, user.level))
        saveFriends(ctx, cur)
        val serverUid = com.focusmode.discipline.net.AuthManager.currentUserId()
        if (serverUid != null) {
            com.focusmode.discipline.sync.SyncManager.enqueueFriendAdd(ctx, serverUid, user.id)
        }
        return true
    }

    /** Fake invite-code flow: any non-blank code adds a random seed user. */
    fun addFriendByInvite(ctx: Context, code: String): LeaderUser? {
        if (code.trim().isBlank()) return null
        val cur = getFriends(ctx)
        val taken = cur.map { it.userId }.toHashSet()
        val candidate = mockUsers.firstOrNull { it.id !in taken } ?: return null
        return if (addFriend(ctx, candidate)) candidate else null
    }

    fun removeFriend(ctx: Context, userId: String) {
        saveFriends(ctx, getFriends(ctx).filter { it.userId != userId })
        val serverUid = com.focusmode.discipline.net.AuthManager.currentUserId()
        if (serverUid != null) {
            com.focusmode.discipline.sync.SyncManager.enqueueFriendRemove(ctx, serverUid, userId)
        }
    }

    /** Leaderboard that includes me + all friends (by their mock score). */
    fun getFriendsLeaderboard(ctx: Context): List<LeaderboardEntry> {
        val me = getCurrentUser(ctx)
        val myScore = getCurrentUserScore(ctx)
        val rows = mutableListOf(Triple(me.id, me.name, myScore))
        getFriends(ctx).forEach { f ->
            rows.add(Triple(f.userId, f.name, mockScoreFor(f.userId)))
        }
        return rankRows(rows, me.id)
    }

    // ------------ Ranking helper ------------

    private fun rankRows(
        rows: MutableList<Triple<String, String, Int>>,
        currentUserId: String
    ): List<LeaderboardEntry> {
        rows.sortByDescending { it.third }
        return rows.mapIndexed { index, (id, name, score) ->
            LeaderboardEntry(
                userId = id,
                name = name,
                avatarLetter = LeaderUser.firstLetter(name),
                score = score,
                rank = index + 1,
                isCurrentUser = (id == currentUserId)
            )
        }
    }

    // ------------ Invite code generator ------------

    private fun newInviteCode(): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // no confusing chars
        return (1..6).map { alphabet.random() }.joinToString("")
    }

    // ===== Backend-backed leaderboard reads =====

    /**
     * Fetch the real public leaderboard from Supabase (get_public_leaderboard RPC).
     * Returns null on failure / offline. Caller should fall back to getPublicLeaderboard().
     */
    suspend fun fetchPublicLeaderboardFromBackend(ctx: Context): List<LeaderboardEntry>? {
        val me = getCurrentUser(ctx)
        if (me.course.isBlank() || me.level.isBlank() || me.attempt.isBlank() || me.attempt == "TBD") return null
        val rows = BackendRepo.getPublicLeaderboard(me.course, me.level, me.attempt).getOrNull()
            ?: return null
        val meUid = AuthManager.currentUserId()
        return rows.map { r ->
            LeaderboardEntry(
                userId = r.userId,
                name = r.name,
                avatarLetter = r.avatarLetter ?: LeaderUser.firstLetter(r.name),
                score = r.score,
                rank = r.rank,
                isCurrentUser = (r.userId == meUid)
            )
        }
    }

    /**
     * Fetch a group's leaderboard from Supabase (get_group_leaderboard RPC).
     * Returns null on failure / offline.
     */
    suspend fun fetchGroupLeaderboardFromBackend(ctx: Context, groupId: String): List<LeaderboardEntry>? {
        val rows = BackendRepo.getGroupLeaderboard(groupId).getOrNull() ?: return null
        val meUid = AuthManager.currentUserId()
        return rows.map { r ->
            LeaderboardEntry(
                userId = r.userId,
                name = r.name,
                avatarLetter = r.avatarLetter ?: LeaderUser.firstLetter(r.name),
                score = r.score,
                rank = r.rank,
                isCurrentUser = (r.userId == meUid)
            )
        }
    }
}
