package com.focusmode.discipline

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Local storage for dashboard data: tasks, pending backlog, focus time (total + today), streak.
 * Kept in its own SharedPreferences file (`task_prefs`).
 *
 * A task becomes "pending" once its creation date is more than PENDING_THRESHOLD_DAYS old
 * AND it's still in status "pending".
 */
object TaskPrefs {
    private const val FILE = "task_prefs"
    private const val KEY_TASKS = "tasks_v1"
    private const val KEY_FOCUS_TOTAL_MS = "focus_total_ms"
    private const val KEY_FOCUS_SESSION_START = "focus_session_start"
    private const val KEY_FOCUS_DAY_PREFIX = "focus_day_"        // + YYYY-MM-DD
    private const val KEY_STREAK_CURRENT = "streak_current"
    private const val KEY_STREAK_LAST_DATE = "streak_last_date"
    private const val DEFAULT_DAILY_TASKS = 5
    private const val PENDING_THRESHOLD_DAYS = 2                 // >2 days old = pending

    private val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private fun sp(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun today(): String = dateFmt.format(Date())

    private fun yesterday(): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_MONTH, -1)
        return dateFmt.format(c.time)
    }

    private fun dateMinusDays(days: Int): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_MONTH, -days)
        return dateFmt.format(c.time)
    }

    // ---------------- Tasks ----------------

    fun getAllTasks(ctx: Context): List<TaskItem> {
        val raw = sp(ctx).getString(KEY_TASKS, "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            TaskItem(
                id = o.optString("id"),
                title = o.optString("title"),
                status = o.optString("status", "pending"),
                date = o.optString("date")
            )
        }
    }

    private fun saveTasks(ctx: Context, tasks: List<TaskItem>) {
        val arr = JSONArray()
        tasks.forEach {
            val o = JSONObject()
            o.put("id", it.id)
            o.put("title", it.title)
            o.put("status", it.status)
            o.put("date", it.date)
            arr.put(o)
        }
        sp(ctx).edit().putString(KEY_TASKS, arr.toString()).apply()
    }

    /** Optional helper to seed today. Not called automatically any more. */
    fun ensureTodayTasks(ctx: Context) {
        val today = today()
        val all = getAllTasks(ctx).toMutableList()
        if (all.any { it.date == today }) return
        for (i in 1..DEFAULT_DAILY_TASKS) {
            all.add(
                TaskItem(
                    id = UUID.randomUUID().toString(),
                    title = "Lecture $i",
                    status = "pending",
                    date = today
                )
            )
        }
        saveTasks(ctx, all)
    }

    fun addTask(ctx: Context, title: String, date: String = today()) {
        val all = getAllTasks(ctx).toMutableList()
        all.add(
            TaskItem(
                id = UUID.randomUUID().toString(),
                title = title,
                status = "pending",
                date = date
            )
        )
        saveTasks(ctx, all)
    }

    fun getTodayTasks(ctx: Context): List<TaskItem> {
        val today = today()
        return getAllTasks(ctx).filter { it.date == today }
    }

    /**
     * "Pending" = task created >PENDING_THRESHOLD_DAYS days ago and still pending.
     * Tasks from yesterday/today that are still unfinished are NOT pending yet.
     */
    fun getPendingTasks(ctx: Context): List<TaskItem> {
        val cutoff = dateMinusDays(PENDING_THRESHOLD_DAYS)
        return getAllTasks(ctx).filter { it.status == "pending" && it.date < cutoff }
    }

    fun markCompleted(ctx: Context, id: String) {
        val all = getAllTasks(ctx).toMutableList()
        val idx = all.indexOfFirst { it.id == id }
        if (idx < 0) return
        if (all[idx].status == "completed") return
        all[idx] = all[idx].copy(status = "completed")
        saveTasks(ctx, all)
        bumpStreakOnComplete(ctx)
    }

    /** Undo a completion — set back to pending. Streak is intentionally NOT decremented. */
    fun markPending(ctx: Context, id: String) {
        val all = getAllTasks(ctx).toMutableList()
        val idx = all.indexOfFirst { it.id == id }
        if (idx < 0) return
        if (all[idx].status == "pending") return
        all[idx] = all[idx].copy(status = "pending")
        saveTasks(ctx, all)
    }

    private fun bumpStreakOnComplete(ctx: Context) {
        val s = sp(ctx)
        val today = today()
        val lastDate = s.getString(KEY_STREAK_LAST_DATE, null)
        val current = s.getInt(KEY_STREAK_CURRENT, 0)
        val newStreak = when {
            lastDate == today -> current.coerceAtLeast(1)
            lastDate == yesterday() -> current + 1
            else -> 1
        }
        s.edit()
            .putInt(KEY_STREAK_CURRENT, newStreak)
            .putString(KEY_STREAK_LAST_DATE, today)
            .apply()
    }

    fun getStreak(ctx: Context): Int {
        val s = sp(ctx)
        val last = s.getString(KEY_STREAK_LAST_DATE, null) ?: return 0
        val today = today()
        val y = yesterday()
        return if (last == today || last == y) s.getInt(KEY_STREAK_CURRENT, 0) else 0
    }

    /** Count of today's completed tasks - shown as "Done" on the stats card. */
    fun getTodayDoneCount(ctx: Context): Int =
        getTodayTasks(ctx).count { it.status == "completed" }

    // ---------------- Focus session tracking ----------------

    fun startFocusSession(ctx: Context) {
        sp(ctx).edit().putLong(KEY_FOCUS_SESSION_START, System.currentTimeMillis()).apply()
    }

    fun endFocusSession(ctx: Context) {
        val s = sp(ctx)
        val start = s.getLong(KEY_FOCUS_SESSION_START, 0L)
        if (start <= 0L) return
        val elapsed = (System.currentTimeMillis() - start).coerceAtLeast(0L)
        val total = s.getLong(KEY_FOCUS_TOTAL_MS, 0L)
        val dayKey = KEY_FOCUS_DAY_PREFIX + today()
        val dayTotal = s.getLong(dayKey, 0L)
        s.edit()
            .putLong(KEY_FOCUS_TOTAL_MS, total + elapsed)
            .putLong(dayKey, dayTotal + elapsed)
            .putLong(KEY_FOCUS_SESSION_START, 0L)
            .apply()
        // Backend sync: summary only, idempotent.
        runCatching { com.focusmode.discipline.sync.SyncManager.syncProgressFromLocal(ctx) }
    }

    /** Today's focus ms. Includes an in-progress session. */
    fun getTodayFocusMs(ctx: Context): Long {
        val s = sp(ctx)
        val stored = s.getLong(KEY_FOCUS_DAY_PREFIX + today(), 0L)
        val start = s.getLong(KEY_FOCUS_SESSION_START, 0L)
        val live = if (start > 0) System.currentTimeMillis() - start else 0L
        return stored + live.coerceAtLeast(0L)
    }

    fun getTotalFocusMs(ctx: Context): Long {
        val s = sp(ctx)
        val total = s.getLong(KEY_FOCUS_TOTAL_MS, 0L)
        val start = s.getLong(KEY_FOCUS_SESSION_START, 0L)
        val live = if (start > 0) System.currentTimeMillis() - start else 0L
        return total + live.coerceAtLeast(0L)
    }

    /** Hours, as a float, for analytics display. */
    fun getTotalFocusHours(ctx: Context): Double =
        getTotalFocusMs(ctx).toDouble() / (1000.0 * 60 * 60)

    /** Count of tasks considered "pending" (older than threshold and still unfinished). */
    fun getPendingCount(ctx: Context): Int = getPendingTasks(ctx).size
}
