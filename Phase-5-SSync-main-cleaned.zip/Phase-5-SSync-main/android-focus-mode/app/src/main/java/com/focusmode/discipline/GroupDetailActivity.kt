package com.focusmode.discipline

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

/**
 * Group detail: leaderboard inside a group + members section + invite code.
 * Owner can leave the group (removes it from local storage).
 */
class GroupDetailActivity : AppCompatActivity() {

    private lateinit var nameView: TextView
    private lateinit var descView: TextView
    private lateinit var codeView: TextView
    private lateinit var copyBtn: Button
    private lateinit var podium: View
    private lateinit var listContainer: LinearLayout
    private lateinit var membersContainer: LinearLayout
    private lateinit var leaveBtn: Button

    private var groupId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_group_detail)

        groupId = intent.getStringExtra("group_id") ?: ""
        nameView = findViewById(R.id.gdName)
        descView = findViewById(R.id.gdDesc)
        codeView = findViewById(R.id.gdCode)
        copyBtn = findViewById(R.id.gdCopyBtn)
        podium = findViewById(R.id.gdPodium)
        listContainer = findViewById(R.id.gdListContainer)
        membersContainer = findViewById(R.id.gdMembersContainer)
        leaveBtn = findViewById(R.id.gdLeaveBtn)

        copyBtn.setOnClickListener { copyCode() }
        leaveBtn.setOnClickListener { confirmLeave() }
    }

    override fun onResume() {
        super.onResume()
        render()
        // Background refresh from Supabase so members & leaderboard reflect other users' joins.
        lifecycleScope.launch {
            LeaderboardRepo.refreshGroupFromBackend(this@GroupDetailActivity, groupId)
            val serverEntries = LeaderboardRepo.fetchGroupLeaderboardFromBackend(
                this@GroupDetailActivity, groupId
            )
            if (serverEntries != null) {
                LeaderboardUi.render(
                    android.view.LayoutInflater.from(this@GroupDetailActivity),
                    podium, listContainer, serverEntries
                )
            }
            // Re-render members from the just-refreshed local cache.
            renderMembersOnly()
        }
    }

    private fun renderMembersOnly() {
        membersContainer.removeAllViews()
        val inflater = android.view.LayoutInflater.from(this)
        LeaderboardRepo.getGroupMembers(this, groupId).forEach { user ->
            val row = inflater.inflate(R.layout.item_friend_row, membersContainer, false)
            row.findViewById<TextView>(R.id.friendAvatar).text = user.avatarLetter
            row.findViewById<TextView>(R.id.friendName).text = user.name
            row.findViewById<TextView>(R.id.friendMeta).text = "${user.course} · ${user.level}"
            row.findViewById<android.widget.Button>(R.id.friendAction).visibility = View.GONE
            membersContainer.addView(row)
        }
    }

    private fun render() {
        val g = LeaderboardRepo.getGroup(this, groupId)
        if (g == null) { finish(); return }
        nameView.text = g.name
        if (g.description.isBlank()) descView.visibility = View.GONE
        else { descView.visibility = View.VISIBLE; descView.text = g.description }
        codeView.text = g.inviteCode

        val entries = LeaderboardRepo.getGroupLeaderboard(this, groupId)
        LeaderboardUi.render(LayoutInflater.from(this), podium, listContainer, entries)

        // Members section
        membersContainer.removeAllViews()
        val inflater = LayoutInflater.from(this)
        LeaderboardRepo.getGroupMembers(this, groupId).forEach { user ->
            val row = inflater.inflate(R.layout.item_friend_row, membersContainer, false)
            row.findViewById<TextView>(R.id.friendAvatar).text = user.avatarLetter
            row.findViewById<TextView>(R.id.friendName).text = user.name
            row.findViewById<TextView>(R.id.friendMeta).text =
                "${user.course} · ${user.level}"
            val action = row.findViewById<Button>(R.id.friendAction)
            action.visibility = View.GONE
            membersContainer.addView(row)
        }
    }

    private fun copyCode() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("invite", codeView.text.toString()))
        Toast.makeText(this, R.string.lb_copied, Toast.LENGTH_SHORT).show()
    }

    private fun confirmLeave() {
        AlertDialog.Builder(this)
            .setTitle(R.string.lb_leave_group)
            .setMessage(R.string.lb_leave_confirm)
            .setPositiveButton(R.string.lb_leave) { _, _ ->
                LeaderboardRepo.deleteGroup(this, groupId)
                finish()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
