package com.focusmode.discipline

import android.app.Application
import com.focusmode.discipline.net.AuthManager
import com.focusmode.discipline.sync.SyncManager

/**
 * App entry-point. Performs one-shot initialization:
 *   - Touches the Supabase client so its session is restored from storage.
 *   - Schedules an initial sync attempt (no-op if queue is empty).
 */
class AppInit : Application() {
    override fun onCreate() {
        super.onCreate()
        // Force lazy init of Supabase so its Auth plugin restores any cached session.
        runCatching { AuthManager.hasSession() }
        // Kick the sync worker — harmless if nothing's queued.
        SyncManager.triggerSyncNow(this)
    }
}
