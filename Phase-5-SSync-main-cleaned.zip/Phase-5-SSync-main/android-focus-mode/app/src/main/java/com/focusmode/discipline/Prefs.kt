package com.focusmode.discipline

import android.content.Context
import android.content.SharedPreferences

/**
 * SharedPreferences wrapper for:
 *  - Blocking state (blocked packages, focus active, session broken) — existing
 *  - Focus session timer + breaks (new)
 *
 * Session lifecycle:
 *   idle -> active <-> on-break -> active -> completed (or broken)
 */
object Prefs {
    private const val FILE = "focus_mode_prefs"

    // Existing
    private const val KEY_BLOCKED = "blocked_packages"
    private const val KEY_FOCUS_ACTIVE = "focus_active"
    private const val KEY_SESSION_BROKEN = "session_broken"

    // New — session + timer
    private const val KEY_SESSION_STATUS = "session_status" // "idle"|"active"|"on-break"|"completed"|"broken"
    private const val KEY_FOCUS_TOTAL_MS = "session_total_ms"
    private const val KEY_FOCUS_REMAINING_MS = "session_remaining_ms"
    private const val KEY_FOCUS_RESUMED_AT = "session_resumed_at" // epoch ms; 0 if not running
    private const val KEY_BREAKS_ALLOWED = "breaks_allowed"
    private const val KEY_BREAKS_USED = "breaks_used"
    private const val KEY_BREAK_DURATION_MS = "break_duration_ms"
    private const val KEY_BREAK_ENDS_AT = "break_ends_at"
    private const val KEY_TOTAL_BREAK_MS = "total_break_ms"

    private fun sp(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ---------- Blocking (existing) ----------

    fun getBlockedPackages(ctx: Context): Set<String> =
        sp(ctx).getStringSet(KEY_BLOCKED, emptySet()) ?: emptySet()

    fun setBlockedPackages(ctx: Context, packages: Set<String>) {
        sp(ctx).edit().putStringSet(KEY_BLOCKED, packages).apply()
    }

    fun isFocusActive(ctx: Context): Boolean =
        sp(ctx).getBoolean(KEY_FOCUS_ACTIVE, false)

    fun setFocusActive(ctx: Context, active: Boolean) {
        sp(ctx).edit().putBoolean(KEY_FOCUS_ACTIVE, active).apply()
    }

    fun isSessionBroken(ctx: Context): Boolean =
        sp(ctx).getBoolean(KEY_SESSION_BROKEN, false)

    fun setSessionBroken(ctx: Context, broken: Boolean) {
        sp(ctx).edit().putBoolean(KEY_SESSION_BROKEN, broken).apply()
    }

    // ---------- Session state ----------

    fun getSessionStatus(ctx: Context): String =
        sp(ctx).getString(KEY_SESSION_STATUS, "idle") ?: "idle"

    fun getTotalMs(ctx: Context): Long = sp(ctx).getLong(KEY_FOCUS_TOTAL_MS, 0L)
    fun getBreaksAllowed(ctx: Context): Int = sp(ctx).getInt(KEY_BREAKS_ALLOWED, 0)
    fun getBreaksUsed(ctx: Context): Int = sp(ctx).getInt(KEY_BREAKS_USED, 0)
    fun getBreakDurationMs(ctx: Context): Long = sp(ctx).getLong(KEY_BREAK_DURATION_MS, 0L)
    fun getTotalBreakMs(ctx: Context): Long = sp(ctx).getLong(KEY_TOTAL_BREAK_MS, 0L)

    /** Focus time remaining in ms, accounting for live run since last resume. */
    fun getFocusRemainingMs(ctx: Context): Long {
        val s = sp(ctx)
        val status = s.getString(KEY_SESSION_STATUS, "idle")
        if (status != "active") return s.getLong(KEY_FOCUS_REMAINING_MS, 0L)
        val stored = s.getLong(KEY_FOCUS_REMAINING_MS, 0L)
        val resumedAt = s.getLong(KEY_FOCUS_RESUMED_AT, 0L)
        if (resumedAt <= 0) return stored
        val elapsed = (System.currentTimeMillis() - resumedAt).coerceAtLeast(0L)
        return (stored - elapsed).coerceAtLeast(0L)
    }

    /** Break time remaining in ms, based on absolute end timestamp. */
    fun getBreakRemainingMs(ctx: Context): Long {
        val endsAt = sp(ctx).getLong(KEY_BREAK_ENDS_AT, 0L)
        if (endsAt <= 0) return 0L
        return (endsAt - System.currentTimeMillis()).coerceAtLeast(0L)
    }

    fun startSession(ctx: Context, totalMs: Long, breaksAllowed: Int, breakDurationMs: Long) {
        sp(ctx).edit()
            .putString(KEY_SESSION_STATUS, "active")
            .putLong(KEY_FOCUS_TOTAL_MS, totalMs)
            .putLong(KEY_FOCUS_REMAINING_MS, totalMs)
            .putLong(KEY_FOCUS_RESUMED_AT, System.currentTimeMillis())
            .putInt(KEY_BREAKS_ALLOWED, breaksAllowed.coerceIn(0, 3))
            .putInt(KEY_BREAKS_USED, 0)
            .putLong(KEY_BREAK_DURATION_MS, breakDurationMs)
            .putLong(KEY_BREAK_ENDS_AT, 0L)
            .putLong(KEY_TOTAL_BREAK_MS, 0L)
            .putBoolean(KEY_FOCUS_ACTIVE, true)
            .putBoolean(KEY_SESSION_BROKEN, false)
            .apply()
    }

    /** Pauses the focus timer and enters break state. */
    fun beginBreak(ctx: Context) {
        val s = sp(ctx)
        val remaining = getFocusRemainingMs(ctx)
        val breakMs = s.getLong(KEY_BREAK_DURATION_MS, 0L)
        s.edit()
            .putString(KEY_SESSION_STATUS, "on-break")
            .putLong(KEY_FOCUS_REMAINING_MS, remaining)
            .putLong(KEY_FOCUS_RESUMED_AT, 0L)
            .putLong(KEY_BREAK_ENDS_AT, System.currentTimeMillis() + breakMs)
            .putInt(KEY_BREAKS_USED, s.getInt(KEY_BREAKS_USED, 0) + 1)
            .putBoolean(KEY_FOCUS_ACTIVE, false) // so AppMonitorService stops polling
            .apply()
    }

    /** Resumes focus after a break. Adds break duration to the cumulative break time. */
    fun endBreak(ctx: Context) {
        val s = sp(ctx)
        val breakMs = s.getLong(KEY_BREAK_DURATION_MS, 0L)
        val totalBreak = s.getLong(KEY_TOTAL_BREAK_MS, 0L)
        s.edit()
            .putString(KEY_SESSION_STATUS, "active")
            .putLong(KEY_BREAK_ENDS_AT, 0L)
            .putLong(KEY_FOCUS_RESUMED_AT, System.currentTimeMillis())
            .putLong(KEY_TOTAL_BREAK_MS, totalBreak + breakMs)
            .putBoolean(KEY_FOCUS_ACTIVE, true)
            .apply()
    }

    /** Session reached zero naturally. */
    fun completeSession(ctx: Context) {
        sp(ctx).edit()
            .putString(KEY_SESSION_STATUS, "completed")
            .putLong(KEY_FOCUS_REMAINING_MS, 0L)
            .putLong(KEY_FOCUS_RESUMED_AT, 0L)
            .putBoolean(KEY_FOCUS_ACTIVE, false)
            .apply()
    }

    /** User forced end via anti-exit flow. */
    fun endSessionBroken(ctx: Context) {
        sp(ctx).edit()
            .putString(KEY_SESSION_STATUS, "broken")
            .putLong(KEY_FOCUS_RESUMED_AT, 0L)
            .putBoolean(KEY_FOCUS_ACTIVE, false)
            .putBoolean(KEY_SESSION_BROKEN, true)
            .apply()
    }

    /** Clears session back to idle (for "Reset Session" and new session). */
    fun resetSession(ctx: Context) {
        sp(ctx).edit()
            .putString(KEY_SESSION_STATUS, "idle")
            .putLong(KEY_FOCUS_TOTAL_MS, 0L)
            .putLong(KEY_FOCUS_REMAINING_MS, 0L)
            .putLong(KEY_FOCUS_RESUMED_AT, 0L)
            .putLong(KEY_BREAK_ENDS_AT, 0L)
            .putInt(KEY_BREAKS_USED, 0)
            .putLong(KEY_TOTAL_BREAK_MS, 0L)
            .putBoolean(KEY_FOCUS_ACTIVE, false)
            .putBoolean(KEY_SESSION_BROKEN, false)
            .apply()
    }
}
