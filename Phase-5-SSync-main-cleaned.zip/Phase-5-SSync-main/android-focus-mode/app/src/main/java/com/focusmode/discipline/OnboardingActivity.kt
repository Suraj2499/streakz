package com.focusmode.discipline

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.ViewFlipper
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar

/**
 * Three-step onboarding using selectable option cards.
 * Step 1: Course (CA / CS / CMA)
 * Step 2: Level (Foundation / Inter / Final)
 * Step 3: Exam Attempt (Month + Year)
 */
class OnboardingActivity : AppCompatActivity() {

    private lateinit var flipper: ViewFlipper
    private lateinit var stepIndicator: TextView
    private lateinit var dot1: View
    private lateinit var dot2: View
    private lateinit var dot3: View

    private var selCourse: String? = null
    private var selLevel: String? = null
    private var selMonth: Int = Calendar.getInstance().get(Calendar.MONTH) + 1
    private var selYear: Int = Calendar.getInstance().get(Calendar.YEAR)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)

        flipper = findViewById(R.id.flipper)
        stepIndicator = findViewById(R.id.stepIndicator)
        dot1 = findViewById(R.id.dot1)
        dot2 = findViewById(R.id.dot2)
        dot3 = findViewById(R.id.dot3)
        updateStepIndicator()

        // ---------- Step 1: Course ----------
        val courseCards = listOf<LinearLayout>(
            findViewById(R.id.courseCaCard),
            findViewById(R.id.courseCsCard),
            findViewById(R.id.courseCmaCard)
        )
        courseCards.forEach { card ->
            card.setOnClickListener {
                courseCards.forEach { it.isSelected = false }
                card.isSelected = true
                selCourse = card.tag as String
            }
        }
        findViewById<Button>(R.id.courseNext).setOnClickListener {
            val sel = selCourse
            if (sel == null) {
                Toast.makeText(this, R.string.onb_pick_course, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            UserPrefs.saveCourse(this, sel)
            updateLevelLabels(sel)
            flipper.displayedChild = 1
            updateStepIndicator()
        }

        // ---------- Step 2: Level ----------
        val levelCards = listOf<LinearLayout>(
            findViewById(R.id.levelFoundationCard),
            findViewById(R.id.levelInterCard),
            findViewById(R.id.levelFinalCard)
        )
        levelCards.forEach { card ->
            card.setOnClickListener {
                levelCards.forEach { it.isSelected = false }
                card.isSelected = true
                selLevel = card.tag as String
            }
        }
        findViewById<Button>(R.id.levelBack).setOnClickListener {
            flipper.displayedChild = 0
            updateStepIndicator()
        }
        findViewById<Button>(R.id.levelNext).setOnClickListener {
            val sel = selLevel
            if (sel == null) {
                Toast.makeText(this, R.string.onb_pick_level, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            UserPrefs.saveLevel(this, sel)
            flipper.displayedChild = 2
            updateStepIndicator()
        }

        // ---------- Step 3: Exam Attempt ----------
        val monthPicker: android.widget.NumberPicker = findViewById(R.id.monthPicker)
        val yearPicker: android.widget.NumberPicker = findViewById(R.id.yearPicker)
        val months = arrayOf(
            "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        )
        monthPicker.minValue = 1
        monthPicker.maxValue = 12
        monthPicker.displayedValues = months
        monthPicker.value = selMonth
        monthPicker.wrapSelectorWheel = true
        monthPicker.setOnValueChangedListener { _, _, v -> selMonth = v }

        val nowYear = Calendar.getInstance().get(Calendar.YEAR)
        yearPicker.minValue = nowYear
        yearPicker.maxValue = nowYear + 5
        yearPicker.value = selYear
        yearPicker.wrapSelectorWheel = false
        yearPicker.setOnValueChangedListener { _, _, v -> selYear = v }

        findViewById<Button>(R.id.examBack).setOnClickListener {
            flipper.displayedChild = 1
            updateStepIndicator()
        }
        findViewById<Button>(R.id.examFinish).setOnClickListener {
            val mm = selMonth.toString().padStart(2, '0')
            val yyyy = selYear.toString()
            UserPrefs.saveExamMonth(this, "$mm/$yyyy")
            UserPrefs.markOnboardingCompleted(this)

            startActivity(
                Intent(this, DashboardActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            )
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (flipper.displayedChild > 0) {
            flipper.displayedChild = flipper.displayedChild - 1
            updateStepIndicator()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    private fun updateStepIndicator() {
        val step = flipper.displayedChild + 1
        stepIndicator.text = getString(R.string.onb_step_indicator, step, 3)
        val primary = getColor(R.color.primary)
        val muted = getColor(R.color.border)
        dot1.setBackgroundColor(if (step >= 1) primary else muted)
        dot2.setBackgroundColor(if (step >= 2) primary else muted)
        dot3.setBackgroundColor(if (step >= 3) primary else muted)
    }

    /** Relabel the Inter / Final level cards so CS shows Executive / Professional. */
    private fun updateLevelLabels(course: String) {
        val interTitle = findViewById<TextView>(R.id.levelInterTitle)
        val finalTitle = findViewById<TextView>(R.id.levelFinalTitle)
        if (course.equals("CS", ignoreCase = true)) {
            interTitle.text = "Executive"
            finalTitle.text = "Professional"
        } else {
            interTitle.text = "Intermediate"
            finalTitle.text = "Final"
        }
    }
}
