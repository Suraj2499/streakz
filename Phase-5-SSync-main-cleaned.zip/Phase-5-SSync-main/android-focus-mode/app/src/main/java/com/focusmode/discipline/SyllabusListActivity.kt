package com.focusmode.discipline

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Generic intermediate syllabus list — renders Groups / Subjects / Sub-subjects
 * depending on the `mode` intent extra.
 *
 * Extras:
 *   mode: "groups" | "subjects" | "subsubjects"
 *   course, level                  (always required)
 *   group      (required for subjects when level has groups, and subsubjects)
 *   subject    (required for subsubjects)
 *
 * Clicking an entry routes to the next level in the hierarchy:
 *   groups → SyllabusListActivity(mode=subjects, group=<picked>)
 *   subjects → SubsubjectsActivity OR ChaptersActivity (if no subsubjects)
 *   subsubjects → ChaptersActivity
 */
class SyllabusListActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MODE = "mode"
        const val EXTRA_COURSE = "course"
        const val EXTRA_LEVEL = "level"
        const val EXTRA_GROUP = "group"
        const val EXTRA_SUBJECT = "subject"
        const val EXTRA_SUBSUBJECT = "subsubject"

        const val MODE_GROUPS = "groups"
        const val MODE_SUBJECTS = "subjects"
        const val MODE_SUBSUBJECTS = "subsubjects"
    }

    private lateinit var container: LinearLayout
    private lateinit var title: TextView
    private lateinit var subtitle: TextView

    private var mode: String = MODE_GROUPS
    private var course: String = ""
    private var level: String = ""
    private var group: String? = null
    private var subject: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_syllabus_list)

        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_GROUPS
        course = intent.getStringExtra(EXTRA_COURSE) ?: ""
        level = intent.getStringExtra(EXTRA_LEVEL) ?: ""
        group = intent.getStringExtra(EXTRA_GROUP)
        subject = intent.getStringExtra(EXTRA_SUBJECT)

        title = findViewById(R.id.listTitle)
        subtitle = findViewById(R.id.listSubtitle)
        container = findViewById(R.id.listContainer)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        container.removeAllViews()
        val inflater = LayoutInflater.from(this)
        val mappedLevel = SyllabusLoader.displayLevel(course, level)
        val items: List<String>
        val pageTitle: String
        val pageSubtitle: String

        when (mode) {
            MODE_GROUPS -> {
                pageTitle = getString(R.string.sy_pick_group)
                pageSubtitle = "$course • $mappedLevel"
                items = SyllabusLoader.getGroups(this, course, level)
            }
            MODE_SUBJECTS -> {
                pageTitle = getString(R.string.sy_pick_subject)
                pageSubtitle = listOfNotNull(course, mappedLevel, group)
                    .filter { it.isNotBlank() }
                    .joinToString(" • ")
                items = SyllabusLoader.getSubjects(this, course, level, group)
            }
            MODE_SUBSUBJECTS -> {
                pageTitle = subject ?: getString(R.string.sy_pick_subsubject)
                pageSubtitle = listOfNotNull(course, mappedLevel, group).joinToString(" • ")
                items = SyllabusLoader.getSubsubjects(this, course, level, group, subject.orEmpty())
            }
            else -> {
                pageTitle = ""; pageSubtitle = ""; items = emptyList()
            }
        }

        title.text = pageTitle
        subtitle.text = pageSubtitle
        subtitle.visibility = if (pageSubtitle.isBlank()) View.GONE else View.VISIBLE

        if (items.isEmpty()) {
            val empty = TextView(this).apply {
                text = getString(R.string.sy_empty_list)
                setTextColor(getColor(R.color.text_muted))
                setPadding(0, 60, 0, 0)
            }
            container.addView(empty)
            return
        }

        items.forEach { name ->
            val row = inflater.inflate(R.layout.item_syllabus_entry, container, false)
            row.findViewById<TextView>(R.id.entryTitle).text = name
            val sub = row.findViewById<TextView>(R.id.entrySubtitle)
            val hint = buildEntrySubtitle(name)
            if (hint.isNotBlank()) {
                sub.visibility = View.VISIBLE
                sub.text = hint
            } else {
                sub.visibility = View.GONE
            }
            row.setOnClickListener { onEntryClicked(name) }
            container.addView(row)
        }
    }

    /** Show a count hint under each row so users see scope at a glance. */
    private fun buildEntrySubtitle(name: String): String = when (mode) {
        MODE_GROUPS -> {
            val n = SyllabusLoader.getSubjects(this, course, level, name).size
            getString(R.string.sy_subjects_count, n)
        }
        MODE_SUBJECTS -> {
            val ssCount = SyllabusLoader.getSubsubjects(this, course, level, group, name).size
            val chCount = SyllabusLoader.getChapters(this, course, level, group, name, null).size
            if (ssCount > 0) getString(R.string.sy_subsubjects_count, ssCount)
            else getString(R.string.sy_chapters_count, chCount)
        }
        MODE_SUBSUBJECTS -> {
            val n = SyllabusLoader.getChapters(this, course, level, group, subject.orEmpty(), name).size
            getString(R.string.sy_chapters_count, n)
        }
        else -> ""
    }

    private fun onEntryClicked(picked: String) {
        when (mode) {
            MODE_GROUPS -> {
                val i = Intent(this, SyllabusListActivity::class.java)
                    .putExtra(EXTRA_MODE, MODE_SUBJECTS)
                    .putExtra(EXTRA_COURSE, course)
                    .putExtra(EXTRA_LEVEL, level)
                    .putExtra(EXTRA_GROUP, picked)
                startActivity(i)
            }
            MODE_SUBJECTS -> {
                // If subject has sub-subjects, show them; otherwise jump straight to chapters.
                if (SyllabusLoader.hasSubsubjects(this, course, level, group, picked)) {
                    val i = Intent(this, SyllabusListActivity::class.java)
                        .putExtra(EXTRA_MODE, MODE_SUBSUBJECTS)
                        .putExtra(EXTRA_COURSE, course)
                        .putExtra(EXTRA_LEVEL, level)
                        .putExtra(EXTRA_GROUP, group)
                        .putExtra(EXTRA_SUBJECT, picked)
                    startActivity(i)
                } else {
                    startActivity(chaptersIntent(subject = picked, subsubject = null))
                }
            }
            MODE_SUBSUBJECTS -> {
                startActivity(chaptersIntent(subject = subject.orEmpty(), subsubject = picked))
            }
        }
    }

    private fun chaptersIntent(subject: String, subsubject: String?): Intent =
        Intent(this, ChaptersActivity::class.java)
            .putExtra(EXTRA_COURSE, course)
            .putExtra(EXTRA_LEVEL, level)
            .putExtra(EXTRA_GROUP, group)
            .putExtra(EXTRA_SUBJECT, subject)
            .putExtra(EXTRA_SUBSUBJECT, subsubject)
            .putExtra("subject_name", subsubject ?: subject) // display title
}
