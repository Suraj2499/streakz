package com.focusmode.discipline

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

/**
 * Syllabus tab entry point.
 *
 * Uses the user's course + level from UserPrefs to decide what to show at the root:
 *  - If the level has Groups (CA/CMA Intermediate, Final · CS Executive, Professional)
 *    → show a Groups list
 *  - Else (all Foundation levels) → show Subjects directly
 *
 * Clicking a group/subject routes through SyllabusListActivity / ChaptersActivity.
 */
class LecturesActivity : AppCompatActivity() {

    private lateinit var container: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_syllabus)
        container = findViewById(R.id.subjectsContainer)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        BottomNavHelper.setup(this, bottomNav, R.id.nav_lectures)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        container.removeAllViews()

        val user = UserPrefs.getProfile(this)
        val course = user.course.orEmpty()
        val level = user.level.orEmpty()
        val mappedLevel = if (course.isNotBlank() && level.isNotBlank())
            SyllabusLoader.displayLevel(course, level) else level

        findViewById<TextView>(R.id.syllabusHeader).text = getString(R.string.syllabus_title)
        findViewById<TextView>(R.id.syllabusSubheader).text =
            listOfNotNull(course, mappedLevel)
                .filter { it.isNotBlank() }
                .joinToString(" • ")
                .ifBlank { getString(R.string.profile_no_course) }

        if (course.isBlank() || level.isBlank()) {
            val t = TextView(this).apply {
                text = getString(R.string.syllabus_no_course)
                setTextColor(getColor(R.color.text_muted))
                setPadding(0, 40, 0, 0)
            }
            container.addView(t)
            return
        }

        val inflater = LayoutInflater.from(this)
        val groups = SyllabusLoader.getGroups(this, course, level)
        if (groups.isNotEmpty()) {
            // Show groups
            groups.forEach { groupName ->
                val row = inflater.inflate(R.layout.item_subject, container, false)
                row.findViewById<TextView>(R.id.subjectName).text = groupName
                val subjectCount = SyllabusLoader.getSubjects(this, course, level, groupName).size
                row.findViewById<TextView>(R.id.subjectProgress).text =
                    getString(R.string.sy_subjects_count, subjectCount)
                row.setOnClickListener {
                    val i = Intent(this, SyllabusListActivity::class.java)
                        .putExtra(SyllabusListActivity.EXTRA_MODE, SyllabusListActivity.MODE_SUBJECTS)
                        .putExtra(SyllabusListActivity.EXTRA_COURSE, course)
                        .putExtra(SyllabusListActivity.EXTRA_LEVEL, level)
                        .putExtra(SyllabusListActivity.EXTRA_GROUP, groupName)
                    startActivity(i)
                }
                container.addView(row)
            }
        } else {
            // No groups (Foundation) — show subjects directly
            val subjects = SyllabusLoader.getSubjects(this, course, level, null)
            if (subjects.isEmpty()) {
                val t = TextView(this).apply {
                    text = getString(R.string.syllabus_no_subjects)
                    setTextColor(getColor(R.color.text_muted))
                    setPadding(0, 40, 0, 0)
                }
                container.addView(t)
                return
            }
            subjects.forEach { subjectName ->
                val row = inflater.inflate(R.layout.item_subject, container, false)
                row.findViewById<TextView>(R.id.subjectName).text = subjectName
                // Progress: completed chapters / total
                val chapters = SyllabusPrefs.getChaptersForContext(
                    this, course, level, null, subjectName, null
                )
                val done = chapters.count { it.status == "completed" }
                row.findViewById<TextView>(R.id.subjectProgress).text =
                    getString(R.string.syllabus_progress, done, chapters.size)
                row.setOnClickListener {
                    onSubjectClicked(course = course, level = level, group = null, subject = subjectName)
                }
                container.addView(row)
            }
        }
    }

    private fun onSubjectClicked(course: String, level: String, group: String?, subject: String) {
        if (SyllabusLoader.hasSubsubjects(this, course, level, group, subject)) {
            val i = Intent(this, SyllabusListActivity::class.java)
                .putExtra(SyllabusListActivity.EXTRA_MODE, SyllabusListActivity.MODE_SUBSUBJECTS)
                .putExtra(SyllabusListActivity.EXTRA_COURSE, course)
                .putExtra(SyllabusListActivity.EXTRA_LEVEL, level)
                .putExtra(SyllabusListActivity.EXTRA_GROUP, group)
                .putExtra(SyllabusListActivity.EXTRA_SUBJECT, subject)
            startActivity(i)
        } else {
            val i = Intent(this, ChaptersActivity::class.java)
                .putExtra(SyllabusListActivity.EXTRA_COURSE, course)
                .putExtra(SyllabusListActivity.EXTRA_LEVEL, level)
                .putExtra(SyllabusListActivity.EXTRA_GROUP, group)
                .putExtra(SyllabusListActivity.EXTRA_SUBJECT, subject)
                .putExtra(SyllabusListActivity.EXTRA_SUBSUBJECT, null as String?)
                .putExtra("subject_name", subject)
            startActivity(i)
        }
    }
}
