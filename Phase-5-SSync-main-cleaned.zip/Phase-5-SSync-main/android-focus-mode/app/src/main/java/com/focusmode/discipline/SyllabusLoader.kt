package com.focusmode.discipline

import android.content.Context
import org.json.JSONObject

/**
 * One-time parser of `assets/syllabus.json`. Caches in memory for the life of the process.
 *
 * JSON shape: `{ "Sheet1": [ { Course, Level, "Group ", "Subject ", Subsubject, "Chapter ", Subchapter }, ... ] }`
 * Note the trailing spaces in several keys.
 *
 * Hierarchy: Course → Level → (Group?) → Subject → (Sub-subject?) → Chapter → (Subchapter?)
 *
 * Level mapping for UI tags coming from onboarding:
 *   Foundation → Foundation (all)
 *   Inter / Intermediate → CA/CMA: Intermediate, CS: Executive
 *   Final → CA/CMA: Final, CS: Professional
 */
object SyllabusLoader {

    data class Row(
        val course: String,
        val level: String,
        val group: String?,
        val subject: String,
        val subsubject: String?,
        val chapter: String,
        val subchapter: String?
    )

    @Volatile private var loaded = false
    private val rows = ArrayList<Row>(1000)
    private val lock = Any()

    fun ensureLoaded(ctx: Context) {
        if (loaded) return
        synchronized(lock) {
            if (loaded) return
            try {
                val text = ctx.applicationContext.assets.open("syllabus.json")
                    .bufferedReader().use { it.readText() }
                val root = JSONObject(text)
                val arr = root.optJSONArray("Sheet1") ?: return
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val course = pickString(o, "Course") ?: continue
                    val level = pickString(o, "Level") ?: continue
                    val group = pickString(o, "Group ", "Group")
                    val subject = pickString(o, "Subject ", "Subject") ?: continue
                    val subsubject = pickString(o, "Subsubject")
                    val chapter = pickString(o, "Chapter ", "Chapter") ?: continue
                    val subchapter = pickString(o, "Subchapter")
                    rows.add(Row(course, level, group, subject, subsubject, chapter, subchapter))
                }
            } catch (_: Throwable) {
                // keep loaded=false so next call retries; but don't crash
            }
            loaded = true
        }
    }

    private fun pickString(o: JSONObject, vararg keys: String): String? {
        for (k in keys) {
            if (o.has(k) && !o.isNull(k)) {
                val v = o.optString(k).trim()
                if (v.isNotEmpty() && v != "null") return v
            }
        }
        return null
    }

    // ---------------- Level mapping ----------------

    /**
     * Maps the onboarding-stored level tag to the actual JSON level string for the given course.
     * - Foundation → Foundation
     * - Inter / Intermediate → CS=Executive, else Intermediate
     * - Final → CS=Professional, else Final
     * Anything else is passed through as-is.
     */
    fun mapLevel(course: String, level: String): String {
        val c = course.trim()
        val l = level.trim()
        if (l.equals("Foundation", true)) return "Foundation"
        if (l.equals("Inter", true) || l.equals("Intermediate", true)) {
            return if (c.equals("CS", true)) "Executive" else "Intermediate"
        }
        if (l.equals("Final", true)) {
            return if (c.equals("CS", true)) "Professional" else "Final"
        }
        return l
    }

    /** User-facing level label (honors CS naming). */
    fun displayLevel(course: String, level: String): String = mapLevel(course, level)

    // ---------------- Queries ----------------

    fun getGroups(ctx: Context, course: String, level: String): List<String> {
        ensureLoaded(ctx)
        val mapped = mapLevel(course, level)
        return rows.asSequence()
            .filter { ciEq(it.course, course) && ciEq(it.level, mapped) && it.group != null }
            .map { it.group!! }
            .distinct()
            .toList()
    }

    fun hasGroups(ctx: Context, course: String, level: String): Boolean =
        getGroups(ctx, course, level).isNotEmpty()

    fun getSubjects(
        ctx: Context, course: String, level: String, group: String?
    ): List<String> {
        ensureLoaded(ctx)
        val mapped = mapLevel(course, level)
        return rows.asSequence()
            .filter {
                ciEq(it.course, course) && ciEq(it.level, mapped) &&
                    (group.isNullOrBlank() || (it.group != null && ciEq(it.group, group)))
            }
            .map { it.subject }
            .distinct()
            .toList()
    }

    fun getSubsubjects(
        ctx: Context, course: String, level: String, group: String?, subject: String
    ): List<String> {
        ensureLoaded(ctx)
        val mapped = mapLevel(course, level)
        return rows.asSequence()
            .filter {
                ciEq(it.course, course) && ciEq(it.level, mapped) &&
                    (group.isNullOrBlank() || (it.group != null && ciEq(it.group, group))) &&
                    ciEq(it.subject, subject) &&
                    it.subsubject != null
            }
            .map { it.subsubject!! }
            .distinct()
            .toList()
    }

    fun hasSubsubjects(
        ctx: Context, course: String, level: String, group: String?, subject: String
    ): Boolean = getSubsubjects(ctx, course, level, group, subject).isNotEmpty()

    fun getChapters(
        ctx: Context, course: String, level: String, group: String?, subject: String, subsubject: String?
    ): List<String> {
        ensureLoaded(ctx)
        val mapped = mapLevel(course, level)
        return rows.asSequence()
            .filter {
                ciEq(it.course, course) && ciEq(it.level, mapped) &&
                    (group.isNullOrBlank() || (it.group != null && ciEq(it.group, group))) &&
                    ciEq(it.subject, subject) &&
                    (subsubject.isNullOrBlank() || (it.subsubject != null && ciEq(it.subsubject, subsubject)))
            }
            .map { it.chapter }
            .distinct()
            .toList()
    }

    fun getSubchapters(
        ctx: Context, course: String, level: String, group: String?, subject: String,
        subsubject: String?, chapter: String
    ): List<String> {
        ensureLoaded(ctx)
        val mapped = mapLevel(course, level)
        return rows.asSequence()
            .filter {
                ciEq(it.course, course) && ciEq(it.level, mapped) &&
                    (group.isNullOrBlank() || (it.group != null && ciEq(it.group, group))) &&
                    ciEq(it.subject, subject) &&
                    (subsubject.isNullOrBlank() || (it.subsubject != null && ciEq(it.subsubject, subsubject))) &&
                    ciEq(it.chapter, chapter) &&
                    it.subchapter != null
            }
            .map { it.subchapter!! }
            .distinct()
            .toList()
    }

    // ---------------- ID builders (deterministic) ----------------

    fun subjectId(course: String, level: String, group: String?, subject: String, subsubject: String?): String =
        "s|" + norm(course) + "|" + norm(mapLevel(course, level)) + "|" +
            norm(group ?: "_") + "|" + norm(subject) + "|" + norm(subsubject ?: "_")

    fun chapterId(
        course: String, level: String, group: String?, subject: String, subsubject: String?, chapter: String
    ): String = "c|" + norm(course) + "|" + norm(mapLevel(course, level)) + "|" +
        norm(group ?: "_") + "|" + norm(subject) + "|" + norm(subsubject ?: "_") + "|" + norm(chapter)

    private fun norm(s: String): String =
        s.trim().lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "_" }

    private fun ciEq(a: String, b: String) = a.trim().equals(b.trim(), ignoreCase = true)
}
