package com.focusmode.discipline

/**
 * Data model for the Leaderboard/Groups/Friends module.
 * Structured so a future backend can replace local storage 1:1.
 */
data class LeaderUser(
    val id: String,
    val name: String,
    val course: String,
    val level: String,
    val attempt: String,  // e.g. "May 2026"
    val avatarLetter: String = firstLetter(name)
) {
    companion object {
        fun firstLetter(name: String): String =
            name.trim().firstOrNull()?.uppercase() ?: "U"
    }
}

/** A user-created private group. */
data class LeaderGroup(
    val id: String,
    val name: String,
    val description: String,
    val inviteCode: String,
    val memberIds: List<String>,
    val ownerId: String,
    val createdAt: Long
)

/** Single ranked entry shown in any leaderboard list. */
data class LeaderboardEntry(
    val userId: String,
    val name: String,
    val avatarLetter: String,
    val score: Int,
    val rank: Int,
    val isCurrentUser: Boolean
)

/** Friend record (mirrors LeaderUser subset to keep friend screen decoupled from repo internals). */
data class Friend(
    val userId: String,
    val name: String,
    val avatarLetter: String,
    val course: String,
    val level: String
)
