package com.focusmode.discipline.net

import com.focusmode.discipline.BuildConfig
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.postgrest.Postgrest

/**
 * Singleton Supabase client. Initialized lazily so unit tests and offline launches
 * don't block on network.
 *
 * Credentials come from BuildConfig (see app/build.gradle), which are set from the
 * Supabase project's API section. The anon key is public by design; RLS policies
 * enforce row-level security.
 */
object Supabase {
    val client: SupabaseClient by lazy {
        createSupabaseClient(
            supabaseUrl = BuildConfig.SUPABASE_URL,
            supabaseKey = BuildConfig.SUPABASE_ANON_KEY
        ) {
            install(Auth)
            install(Postgrest)
        }
    }
}
