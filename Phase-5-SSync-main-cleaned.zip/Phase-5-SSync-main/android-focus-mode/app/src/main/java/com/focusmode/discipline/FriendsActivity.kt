package com.focusmode.discipline

import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * Friends screen: list of friends + "Friends Leaderboard" (me + friends ranked),
 * with search (mock) and invite-code flows for adding friends.
 */
class FriendsActivity : AppCompatActivity() {

    private lateinit var lbContainer: LinearLayout
    private lateinit var listContainer: LinearLayout
    private lateinit var emptyView: LinearLayout
    private lateinit var lbTitle: TextView
    private lateinit var listTitle: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_friends)

        lbContainer = findViewById(R.id.frLbContainer)
        listContainer = findViewById(R.id.frListContainer)
        emptyView = findViewById(R.id.frEmpty)
        lbTitle = findViewById(R.id.frLbTitle)
        listTitle = findViewById(R.id.frListTitle)

        findViewById<Button>(R.id.searchFriendBtn).setOnClickListener { showSearchDialog() }
        findViewById<Button>(R.id.inviteFriendBtn).setOnClickListener { showInviteDialog() }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val friends = LeaderboardRepo.getFriends(this)
        val inflater = LayoutInflater.from(this)

        // Friends leaderboard (me + friends)
        lbContainer.removeAllViews()
        if (friends.isEmpty()) {
            lbTitle.visibility = View.GONE
        } else {
            lbTitle.visibility = View.VISIBLE
            val entries = LeaderboardRepo.getFriendsLeaderboard(this)
            entries.forEach { entry ->
                val row = inflater.inflate(R.layout.item_leader_row, lbContainer, false)
                LeaderboardUi.bindRow(row, entry)
                lbContainer.addView(row)
            }
        }

        // Friend list with remove action
        listContainer.removeAllViews()
        if (friends.isEmpty()) {
            emptyView.visibility = View.VISIBLE
            listTitle.visibility = View.GONE
            return
        }
        emptyView.visibility = View.GONE
        listTitle.visibility = View.VISIBLE
        friends.forEach { f ->
            val row = inflater.inflate(R.layout.item_friend_row, listContainer, false)
            row.findViewById<TextView>(R.id.friendAvatar).text = f.avatarLetter
            row.findViewById<TextView>(R.id.friendName).text = f.name
            row.findViewById<TextView>(R.id.friendMeta).text = "${f.course} · ${f.level}"
            val action = row.findViewById<Button>(R.id.friendAction)
            action.text = getString(R.string.lb_remove)
            action.setOnClickListener {
                LeaderboardRepo.removeFriend(this, f.userId)
                Toast.makeText(this, R.string.lb_friend_removed, Toast.LENGTH_SHORT).show()
                render()
            }
            listContainer.addView(row)
        }
    }

    private fun showSearchDialog() {
        val input = EditText(this).apply {
            hint = getString(R.string.lb_search_user_hint)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.lb_search_user)
            .setView(input)
            .setPositiveButton(R.string.lb_search) { _, _ ->
                val query = input.text.toString()
                val results = LeaderboardRepo.searchUsers(query)
                if (results.isEmpty()) {
                    Toast.makeText(this, R.string.lb_no_results, Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                showSearchResults(results)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showSearchResults(results: List<LeaderUser>) {
        val labels = results.map { "${it.name}  ·  ${it.course} ${it.level}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.lb_search_results)
            .setItems(labels) { _, which ->
                val picked = results[which]
                val added = LeaderboardRepo.addFriend(this, picked)
                if (added) {
                    Toast.makeText(this, getString(R.string.lb_friend_added_fmt, picked.name),
                        Toast.LENGTH_SHORT).show()
                    render()
                } else {
                    Toast.makeText(this, R.string.lb_already_friend, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showInviteDialog() {
        val input = EditText(this).apply {
            hint = getString(R.string.lb_friend_invite_hint)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.lb_invite_code_add)
            .setView(input)
            .setPositiveButton(R.string.lb_add) { _, _ ->
                val code = input.text.toString()
                val added = LeaderboardRepo.addFriendByInvite(this, code)
                if (added != null) {
                    Toast.makeText(this, getString(R.string.lb_friend_added_fmt, added.name),
                        Toast.LENGTH_SHORT).show()
                    render()
                } else {
                    Toast.makeText(this, R.string.lb_invite_failed, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
