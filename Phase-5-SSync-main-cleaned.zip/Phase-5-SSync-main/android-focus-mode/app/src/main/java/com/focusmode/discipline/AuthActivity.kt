package com.focusmode.discipline

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.focusmode.discipline.net.AuthManager
import com.focusmode.discipline.sync.SyncManager
import kotlinx.coroutines.launch

/**
 * Email + password auth via Supabase.
 * - Signup creates a Supabase auth user + a `public.users` row.
 * - Signin signs into Supabase + hydrates local profile from the server.
 *
 * UI: one card, flips between Signup (name + email + password) and Login (email + password).
 */
class AuthActivity : AppCompatActivity() {

    private var signupMode = true
    private lateinit var submit: Button
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auth)

        val title: TextView = findViewById(R.id.authTitle)
        val nameRow: LinearLayout = findViewById(R.id.nameRow)
        val nameInput: EditText = findViewById(R.id.nameInput)
        val emailInput: EditText = findViewById(R.id.emailInput)
        val passwordInput: EditText = findViewById(R.id.passwordInput)
        val toggle: TextView = findViewById(R.id.toggleMode)
        submit = findViewById(R.id.submitBtn)
        progress = findViewById(R.id.authProgress)

        fun applyMode() {
            if (signupMode) {
                title.setText(R.string.auth_signup_title)
                submit.setText(R.string.auth_signup_btn)
                toggle.setText(R.string.auth_go_to_login)
                nameRow.visibility = View.VISIBLE
            } else {
                title.setText(R.string.auth_login_title)
                submit.setText(R.string.auth_login_btn)
                toggle.setText(R.string.auth_go_to_signup)
                nameRow.visibility = View.GONE
            }
        }
        applyMode()

        toggle.setOnClickListener {
            signupMode = !signupMode
            applyMode()
        }

        submit.setOnClickListener {
            val email = emailInput.text.toString().trim()
            val password = passwordInput.text.toString()
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(this, R.string.auth_invalid_email, Toast.LENGTH_SHORT).show(); return@setOnClickListener
            }
            if (password.length < 6) {
                Toast.makeText(this, R.string.auth_password_short, Toast.LENGTH_SHORT).show(); return@setOnClickListener
            }
            if (signupMode) {
                val name = nameInput.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(this, R.string.auth_name_required, Toast.LENGTH_SHORT).show(); return@setOnClickListener
                }
                doSignup(name, email, password)
            } else {
                doLogin(email, password)
            }
        }
    }

    private fun setLoading(on: Boolean) {
        submit.isEnabled = !on
        progress.visibility = if (on) View.VISIBLE else View.GONE
    }

    private fun doSignup(name: String, email: String, password: String) {
        setLoading(true)
        lifecycleScope.launch {
            val result = AuthManager.signUp(this@AuthActivity, email, password, name)
            setLoading(false)
            result.fold(
                onSuccess = {
                    SyncManager.syncProgressFromLocal(this@AuthActivity)
                    goToLauncher()
                },
                onFailure = { t ->
                    if (t === AuthManager.EmailConfirmationRequired) {
                        // Happy path: show a clear message and flip to login mode.
                        Toast.makeText(this@AuthActivity,
                            R.string.auth_check_email, Toast.LENGTH_LONG).show()
                        signupMode = false
                        recreate()
                    } else {
                        Toast.makeText(this@AuthActivity,
                            getString(R.string.auth_signup_failed_fmt, t.localizedMessage ?: "unknown"),
                            Toast.LENGTH_LONG).show()
                    }
                }
            )
        }
    }

    private fun doLogin(email: String, password: String) {
        setLoading(true)
        lifecycleScope.launch {
            val result = AuthManager.signIn(this@AuthActivity, email, password)
            setLoading(false)
            result.fold(
                onSuccess = {
                    SyncManager.syncProgressFromLocal(this@AuthActivity)
                    goToLauncher()
                },
                onFailure = { t ->
                    Toast.makeText(this@AuthActivity,
                        getString(R.string.auth_login_failed_fmt, t.localizedMessage ?: "invalid credentials"),
                        Toast.LENGTH_LONG).show()
                }
            )
        }
    }

    private fun goToLauncher() {
        startActivity(Intent(this, LauncherActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        finish()
    }
}
