package com.focusmode.discipline

import android.app.AppOpsManager
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * Full-screen countdown timer used by the Syllabus study flow (Self-Study + Watch-Lectures).
 *
 * IMPORTANT: This activity now drives the same Focus engine that MainActivity uses —
 * it calls Prefs.startSession(...) and launches AppMonitorService so the user's configured
 * blocked apps trigger the overlay during a syllabus-driven study session.
 *
 * Anti-exit flow:
 *   Cancel → Stage 1 dialog: Continue Focus / End Session
 *   Stage 2 dialog: Go Back / End Anyway (disabled for 5 seconds)
 *
 * When timer ends naturally we mark chapter/lecture completed or in-progress and stop blocking.
 */
class FocusTimerActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var durationMs: Long = 0
    private var isLecture: Boolean = false
    private var chapterId: String = ""
    private var lectureId: String = ""
    private var label: String = ""

    private lateinit var timerText: TextView
    private lateinit var labelText: TextView
    private lateinit var blockingStatusText: TextView

    // Whether this timer actually activated the blocking engine for this run.
    private var blockingActive: Boolean = false
    private var running = true

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val rem = if (blockingActive) Prefs.getFocusRemainingMs(this@FocusTimerActivity)
                       else remainingLocalMs
            if (rem <= 0) {
                timerText.text = "00:00"
                onTimerFinished()
                return
            }
            timerText.text = format(rem)
            if (!blockingActive) remainingLocalMs -= 1000
            handler.postDelayed(this, 1000)
        }
    }

    // Fallback countdown when blocking isn't active (permissions/apps not set up).
    private var remainingLocalMs: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_focus_timer)

        durationMs = intent.getLongExtra("duration_ms", 0L)
        isLecture = intent.getBooleanExtra("is_lecture", false)
        chapterId = intent.getStringExtra("chapter_id") ?: ""
        lectureId = intent.getStringExtra("lecture_id") ?: ""
        label = intent.getStringExtra("label") ?: ""

        timerText = findViewById(R.id.timerText)
        labelText = findViewById(R.id.timerLabel)
        blockingStatusText = findViewById(R.id.blockingStatus)
        labelText.text = label

        findViewById<Button>(R.id.timerCancelBtn).setOnClickListener { showEndStage1() }

        // Try to activate blocking (uses configured blocked apps) if permissions are granted.
        val alreadyActive = Prefs.getSessionStatus(this) == "active" ||
                            Prefs.getSessionStatus(this) == "on-break"
        val permsOk = hasUsageAccess() && Settings.canDrawOverlays(this)
        val blockedAppsOk = Prefs.getBlockedPackages(this).isNotEmpty()

        if (!alreadyActive && permsOk && blockedAppsOk) {
            // 0 breaks — syllabus sessions run end-to-end
            Prefs.startSession(this, durationMs, 0, 0L)
            TaskPrefs.startFocusSession(this)
            ContextCompat.startForegroundService(this, Intent(this, AppMonitorService::class.java))
            blockingActive = true
            blockingStatusText.text = getString(R.string.focus_state_focus)
            blockingStatusText.setTextColor(getColor(R.color.primary))
        } else {
            // Fall back to a local countdown. Don't interfere with an already-active session.
            remainingLocalMs = durationMs
            blockingActive = false
            if (alreadyActive) {
                blockingStatusText.text = getString(R.string.focus_blocker_session_active)
            } else {
                blockingStatusText.text = getString(R.string.focus_blocker_missing)
            }
            blockingStatusText.setTextColor(getColor(R.color.warning))
        }
        blockingStatusText.visibility = View.VISIBLE
        handler.post(tick)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* block accidental exit */ }

    // ---------- Anti-exit ----------

    private fun showEndStage1() {
        AlertDialog.Builder(this)
            .setTitle(R.string.focus_exit_1_title)
            .setPositiveButton(R.string.focus_exit_1_continue) { d, _ -> d.dismiss() }
            .setNegativeButton(R.string.focus_exit_1_end) { _, _ -> showEndStage2() }
            .show()
    }

    private fun showEndStage2() {
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.focus_exit_2_title)
            .setMessage(R.string.focus_exit_2_msg)
            .setPositiveButton(R.string.focus_exit_2_back) { d, _ -> d.dismiss() }
            .setNegativeButton(R.string.focus_exit_2_end, null)
            .setCancelable(true)
            .create()
        dialog.setOnShowListener {
            val endBtn = dialog.getButton(DialogInterface.BUTTON_NEGATIVE)
            endBtn.isEnabled = false
            var remaining = 5
            endBtn.text = getString(R.string.focus_exit_hold, remaining)
            val r = object : Runnable {
                override fun run() {
                    remaining--
                    if (remaining <= 0) {
                        endBtn.isEnabled = true
                        endBtn.text = getString(R.string.focus_exit_2_end)
                        endBtn.setOnClickListener {
                            dialog.dismiss()
                            cancelBroken()
                        }
                    } else {
                        endBtn.text = getString(R.string.focus_exit_hold, remaining)
                        handler.postDelayed(this, 1000)
                    }
                }
            }
            handler.postDelayed(r, 1000)
        }
        dialog.show()
    }

    private fun cancelBroken() {
        running = false
        if (blockingActive) {
            val plannedMinutes = (durationMs / 60_000L).toInt().coerceAtLeast(1)
            Prefs.endSessionBroken(this)
            TaskPrefs.endFocusSession(this)
            stopService(Intent(this, AppMonitorService::class.java))
            TaskPrefs.addTask(
                this,
                getString(R.string.focus_backlog_task, plannedMinutes),
                date = threeDaysAgo()
            )
            Toast.makeText(this, R.string.focus_broken_toast, Toast.LENGTH_LONG).show()
        }
        finish()
    }

    private fun onTimerFinished() {
        running = false
        if (blockingActive) {
            Prefs.completeSession(this)
            TaskPrefs.endFocusSession(this)
            stopService(Intent(this, AppMonitorService::class.java))
            blockingActive = false
        }
        AlertDialog.Builder(this)
            .setTitle(if (isLecture) R.string.timer_done_lecture else R.string.timer_done_chapter)
            .setCancelable(false)
            .setItems(arrayOf(
                getString(if (isLecture) R.string.timer_lec_completed else R.string.timer_chap_completed),
                getString(R.string.timer_in_progress)
            )) { _: DialogInterface, which: Int ->
                if (which == 0) markCompleted() else handleInProgress()
            }
            .show()
    }

    private fun markCompleted() {
        if (isLecture) {
            SyllabusPrefs.updateLectureStatus(this, lectureId, "completed", durationMs)
        } else {
            SyllabusPrefs.updateChapterStatus(this, chapterId, "completed")
            SyllabusPrefs.scheduleRevisionsForChapter(this, chapterId)
        }
        finish()
    }

    private fun handleInProgress() {
        if (isLecture) {
            SyllabusPrefs.updateLectureStatus(this, lectureId, "in-progress", durationMs)
        } else {
            SyllabusPrefs.updateChapterStatus(this, chapterId, "in-progress")
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.timer_in_progress)
            .setCancelable(false)
            .setItems(arrayOf(
                getString(R.string.timer_start_again),
                getString(R.string.timer_continue_later)
            )) { _, which ->
                if (which == 0) {
                    // Re-launch ourselves fresh so the blocking engine re-activates cleanly.
                    val i = Intent(this, FocusTimerActivity::class.java).apply {
                        putExtra("duration_ms", durationMs)
                        putExtra("label", label)
                        putExtra("chapter_id", chapterId)
                        putExtra("lecture_id", lectureId)
                        putExtra("is_lecture", isLecture)
                    }
                    finish()
                    startActivity(i)
                } else {
                    finish()
                }
            }
            .show()
    }

    // ---------- Utilities ----------

    private fun threeDaysAgo(): String {
        val cal = java.util.Calendar.getInstance()
        cal.add(java.util.Calendar.DAY_OF_MONTH, -3)
        return java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(cal.time)
    }

    private fun format(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        val m = total / 60
        val s = total % 60
        return String.format(java.util.Locale.US, "%02d:%02d", m, s)
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }
}
