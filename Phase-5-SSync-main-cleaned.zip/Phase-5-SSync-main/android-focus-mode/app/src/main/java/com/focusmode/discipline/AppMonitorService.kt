package com.focusmode.discipline

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

/**
 * Foreground service that polls UsageStatsManager for MOVE_TO_FOREGROUND events.
 * If a blocked package is detected while Focus Mode is active, it launches OverlayActivity.
 *
 * Polling approach:
 *  - Every POLL_INTERVAL_MS, query events from (now - QUERY_WINDOW_MS) to now
 *  - Look at the latest foreground event
 *  - If it's a blocked package and we haven't already shown an overlay for this foreground run, trigger
 */
class AppMonitorService : Service() {

    companion object {
        private const val CHANNEL_ID = "focus_mode_monitor"
        private const val NOTIF_ID = 1001
        private const val POLL_INTERVAL_MS = 500L
        private const val QUERY_WINDOW_MS = 10_000L
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var usageStatsManager: UsageStatsManager

    private var lastForegroundPkg: String? = null
    private var overlayShownForPkg: String? = null

    private val pollRunnable = object : Runnable {
        override fun run() {
            try {
                checkForeground()
            } catch (_: Throwable) {
                // never crash the service
            }
            handler.postDelayed(this, POLL_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        startForegroundCompat()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        handler.removeCallbacks(pollRunnable)
        handler.post(pollRunnable)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(pollRunnable)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun checkForeground() {
        if (!Prefs.isFocusActive(this)) {
            stopSelf()
            return
        }
        val blocked = Prefs.getBlockedPackages(this)
        if (blocked.isEmpty()) return

        val end = System.currentTimeMillis()
        val start = end - QUERY_WINDOW_MS
        val events = usageStatsManager.queryEvents(start, end) ?: return

        var latestPkg: String? = null
        var latestTime = 0L
        val ev = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(ev)
            if (ev.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                if (ev.timeStamp >= latestTime) {
                    latestTime = ev.timeStamp
                    latestPkg = ev.packageName
                }
            }
        }

        if (latestPkg == null) return

        if (latestPkg != lastForegroundPkg) {
            lastForegroundPkg = latestPkg
            // Reset the "already shown" tracker when moving away from the blocked app
            if (overlayShownForPkg != null && overlayShownForPkg != latestPkg) {
                overlayShownForPkg = null
            }
        }

        // Don't trigger on our own UI (overlay / main activity)
        if (latestPkg == packageName) return

        if (blocked.contains(latestPkg) && overlayShownForPkg != latestPkg) {
            overlayShownForPkg = latestPkg
            launchOverlay(latestPkg!!)
        }
    }

    private fun launchOverlay(blockedPkg: String) {
        val i = Intent(this, OverlayActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION
            )
            putExtra(OverlayActivity.EXTRA_BLOCKED_PKG, blockedPkg)
        }
        startActivity(i)
    }

    private fun startForegroundCompat() {
        ensureChannel()
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Focus Mode active")
            .setContentText("Monitoring for blocked apps")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun ensureChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val ch = NotificationChannel(
                CHANNEL_ID,
                "Focus Mode Monitor",
                NotificationManager.IMPORTANCE_LOW
            )
            ch.description = "Keeps the focus mode monitor alive"
            nm.createNotificationChannel(ch)
        }
    }
}
