package com.focusmode.discipline

import android.Manifest
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.bottomnavigation.BottomNavigationView

/**
 * Focus screen: session setup + live timer + breaks + anti-exit flow.
 * Delegates blocking to existing AppMonitorService — untouched.
 */
class MainActivity : AppCompatActivity() {

    // Setup views
    private lateinit var setupCard: LinearLayout
    private lateinit var activeCard: LinearLayout
    private lateinit var chip30: TextView; private lateinit var chip45: TextView; private lateinit var chip60: TextView
    private lateinit var customMinutes: EditText
    private lateinit var b0: TextView; private lateinit var b1: TextView; private lateinit var b2: TextView; private lateinit var b3: TextView
    private lateinit var bd5: TextView; private lateinit var bd10: TextView; private lateinit var bd15: TextView
    private lateinit var permsStatusText: TextView
    private lateinit var usagePermBtn: Button
    private lateinit var overlayPermBtn: Button
    private lateinit var selectAppsBtn: Button
    private lateinit var startBtn: Button
    private lateinit var resetSessionBtn: Button

    // Active views
    private lateinit var stateBadge: TextView
    private lateinit var timerText: TextView
    private lateinit var breaksLeftText: TextView
    private lateinit var takeBreakBtn: Button
    private lateinit var endSessionBtn: Button

    // Selected setup values
    private var selectedMinutes: Int = 30
    private var selectedBreaks: Int = 0
    private var selectedBreakMin: Int = 5
    private var suppressEditListener = false

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            renderActive()
            handler.postDelayed(this, 1000)
        }
    }

    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* best-effort */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        wireSetupChips()
        wireButtons()

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        BottomNavHelper.setup(this, bottomNav, R.id.nav_focus)
    }

    override fun onResume() {
        super.onResume()
        render()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    // ---------- Binding ----------

    private fun bindViews() {
        setupCard = findViewById(R.id.setupCard)
        activeCard = findViewById(R.id.activeCard)
        chip30 = findViewById(R.id.chip30); chip45 = findViewById(R.id.chip45); chip60 = findViewById(R.id.chip60)
        customMinutes = findViewById(R.id.customMinutes)
        b0 = findViewById(R.id.breaks0); b1 = findViewById(R.id.breaks1); b2 = findViewById(R.id.breaks2); b3 = findViewById(R.id.breaks3)
        bd5 = findViewById(R.id.bd5); bd10 = findViewById(R.id.bd10); bd15 = findViewById(R.id.bd15)
        permsStatusText = findViewById(R.id.permsStatusText)
        usagePermBtn = findViewById(R.id.usagePermBtn)
        overlayPermBtn = findViewById(R.id.overlayPermBtn)
        selectAppsBtn = findViewById(R.id.selectAppsBtn)
        startBtn = findViewById(R.id.startBtn)
        resetSessionBtn = findViewById(R.id.resetSessionBtn)

        stateBadge = findViewById(R.id.stateBadge)
        timerText = findViewById(R.id.timerText)
        breaksLeftText = findViewById(R.id.breaksLeftText)
        takeBreakBtn = findViewById(R.id.takeBreakBtn)
        endSessionBtn = findViewById(R.id.endSessionBtn)
    }

    private fun wireSetupChips() {
        val durationChips = listOf(chip30, chip45, chip60)
        durationChips.forEach { chip ->
            chip.setOnClickListener {
                selectedMinutes = (chip.tag as String).toInt()
                highlight(durationChips, chip)
                suppressEditListener = true
                customMinutes.setText("")
                suppressEditListener = false
            }
        }
        customMinutes.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (suppressEditListener) return
                val v = s?.toString()?.toIntOrNull()
                if (v != null && v > 0) {
                    selectedMinutes = v
                    durationChips.forEach { it.isSelected = false; paintChip(it) }
                }
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        highlight(durationChips, chip30) // default

        val breakChips = listOf(b0, b1, b2, b3)
        breakChips.forEach { chip ->
            chip.setOnClickListener {
                selectedBreaks = (chip.tag as String).toInt()
                highlight(breakChips, chip)
            }
        }
        highlight(breakChips, b0)

        val breakDurChips = listOf(bd5, bd10, bd15)
        breakDurChips.forEach { chip ->
            chip.setOnClickListener {
                selectedBreakMin = (chip.tag as String).toInt()
                highlight(breakDurChips, chip)
            }
        }
        highlight(breakDurChips, bd5)
    }

    private fun highlight(group: List<TextView>, picked: TextView) {
        group.forEach { it.isSelected = (it === picked); paintChip(it) }
    }

    private fun paintChip(v: TextView) {
        v.setBackgroundResource(if (v.isSelected) R.drawable.bg_tab_active else R.drawable.bg_tab_inactive)
        v.setTextColor(getColor(if (v.isSelected) R.color.black else R.color.text_secondary))
    }

    private fun wireButtons() {
        usagePermBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        overlayPermBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        selectAppsBtn.setOnClickListener {
            startActivity(Intent(this, AppListActivity::class.java))
        }
        startBtn.setOnClickListener { onStartClicked() }
        resetSessionBtn.setOnClickListener {
            Prefs.resetSession(this)
            render()
            Toast.makeText(this, "Session reset", Toast.LENGTH_SHORT).show()
        }
        takeBreakBtn.setOnClickListener { onTakeBreak() }
        endSessionBtn.setOnClickListener { showEndDialog1() }
    }

    // ---------- Session control ----------

    private fun onStartClicked() {
        val minutes = customMinutes.text.toString().toIntOrNull() ?: selectedMinutes
        if (minutes <= 0 || minutes > 240) {
            Toast.makeText(this, R.string.focus_invalid_duration, Toast.LENGTH_SHORT).show()
            return
        }
        if (!hasUsageAccess()) {
            Toast.makeText(this, "Please grant Usage Access first.", Toast.LENGTH_LONG).show(); return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please grant Display over other apps.", Toast.LENGTH_LONG).show(); return
        }
        if (Prefs.getBlockedPackages(this).isEmpty()) {
            Toast.makeText(this, "Select at least one app to block.", Toast.LENGTH_LONG).show(); return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        val totalMs = minutes.toLong() * 60_000L
        val breakMs = selectedBreakMin.toLong() * 60_000L
        Prefs.startSession(this, totalMs, selectedBreaks, breakMs)
        TaskPrefs.startFocusSession(this) // existing analytics hook
        ContextCompat.startForegroundService(this, Intent(this, AppMonitorService::class.java))
        render()
    }

    private fun onTakeBreak() {
        val used = Prefs.getBreaksUsed(this)
        val allowed = Prefs.getBreaksAllowed(this)
        if (allowed <= 0 || used >= allowed) {
            Toast.makeText(this, R.string.focus_no_breaks_remaining, Toast.LENGTH_SHORT).show()
            return
        }
        // Pause focus timer, stop blocking, start break timer
        Prefs.beginBreak(this)
        TaskPrefs.endFocusSession(this) // accumulate focus time so far
        stopService(Intent(this, AppMonitorService::class.java))
        render()
    }

    /** Called when break countdown hits 0. */
    private fun autoResumeFromBreak() {
        Prefs.endBreak(this)
        TaskPrefs.startFocusSession(this)
        ContextCompat.startForegroundService(this, Intent(this, AppMonitorService::class.java))
        render()
    }

    private fun completeSessionNatural() {
        Prefs.completeSession(this)
        TaskPrefs.endFocusSession(this)
        stopService(Intent(this, AppMonitorService::class.java))
        Toast.makeText(this, R.string.focus_completed_toast, Toast.LENGTH_LONG).show()
        render()
    }

    // ---------- Anti-exit flow ----------

    private fun showEndDialog1() {
        AlertDialog.Builder(this)
            .setTitle(R.string.focus_exit_1_title)
            .setPositiveButton(R.string.focus_exit_1_continue) { d, _ -> d.dismiss() }
            .setNegativeButton(R.string.focus_exit_1_end) { _, _ -> showEndDialog2() }
            .show()
    }

    private fun showEndDialog2() {
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.focus_exit_2_title)
            .setMessage(R.string.focus_exit_2_msg)
            .setPositiveButton(R.string.focus_exit_2_back) { d, _ -> d.dismiss() }
            .setNegativeButton(R.string.focus_exit_2_end, null) // wired after show
            .setCancelable(true)
            .create()
        dialog.setOnShowListener {
            val endBtn = dialog.getButton(DialogInterface.BUTTON_NEGATIVE)
            endBtn.isEnabled = false
            var remaining = 5
            endBtn.text = getString(R.string.focus_exit_hold, remaining)
            val tick = object : Runnable {
                override fun run() {
                    remaining--
                    if (remaining <= 0) {
                        endBtn.isEnabled = true
                        endBtn.text = getString(R.string.focus_exit_2_end)
                        endBtn.setOnClickListener {
                            dialog.dismiss()
                            finalizeEndBroken()
                        }
                    } else {
                        endBtn.text = getString(R.string.focus_exit_hold, remaining)
                        handler.postDelayed(this, 1000)
                    }
                }
            }
            handler.postDelayed(tick, 1000)
        }
        dialog.show()
    }

    private fun finalizeEndBroken() {
        // Compute how many minutes were planned so we can log a backlog task
        val totalMinutes = (Prefs.getTotalMs(this) / 60_000L).toInt()
        Prefs.endSessionBroken(this)
        TaskPrefs.endFocusSession(this)
        stopService(Intent(this, AppMonitorService::class.java))
        // Add a backlog task dated 3 days ago so it shows in the "Pending" tab immediately
        TaskPrefs.addTask(
            this,
            getString(R.string.focus_backlog_task, totalMinutes),
            date = threeDaysAgo()
        )
        Toast.makeText(this, R.string.focus_broken_toast, Toast.LENGTH_LONG).show()
        render()
    }

    private fun threeDaysAgo(): String {
        val cal = java.util.Calendar.getInstance()
        cal.add(java.util.Calendar.DAY_OF_MONTH, -3)
        return java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(cal.time)
    }

    // ---------- Render ----------

    private fun render() {
        val status = Prefs.getSessionStatus(this)
        val active = status == "active" || status == "on-break"
        setupCard.visibility = if (active) View.GONE else View.VISIBLE
        activeCard.visibility = if (active) View.VISIBLE else View.GONE
        resetSessionBtn.visibility = if (Prefs.isSessionBroken(this) && !active) View.VISIBLE else View.GONE

        if (!active) renderSetup() else renderActive()
    }

    private fun renderSetup() {
        val hasUsage = hasUsageAccess()
        val hasOverlay = Settings.canDrawOverlays(this)
        val count = Prefs.getBlockedPackages(this).size
        val sb = StringBuilder()
        sb.append("Blocked apps: ").append(count).append('\n')
        sb.append(" \u2022 Usage Access: ").append(if (hasUsage) "GRANTED" else "MISSING").append('\n')
        sb.append(" \u2022 Overlay: ").append(if (hasOverlay) "GRANTED" else "MISSING")
        permsStatusText.text = sb.toString()
        usagePermBtn.visibility = if (hasUsage) View.GONE else View.VISIBLE
        overlayPermBtn.visibility = if (hasOverlay) View.GONE else View.VISIBLE
    }

    private fun renderActive() {
        val status = Prefs.getSessionStatus(this)
        if (status != "active" && status != "on-break") {
            render(); return
        }
        if (status == "on-break") {
            val rem = Prefs.getBreakRemainingMs(this)
            if (rem <= 0L) {
                autoResumeFromBreak()
                return
            }
            stateBadge.setText(R.string.focus_state_break)
            stateBadge.setBackgroundResource(R.drawable.bg_stats_card)
            timerText.text = format(rem)
            timerText.setTextColor(getColor(R.color.streak_orange))
            breaksLeftText.text = getString(R.string.focus_break_auto_resume, format(rem))
            takeBreakBtn.isEnabled = false
            takeBreakBtn.alpha = 0.4f
        } else {
            val rem = Prefs.getFocusRemainingMs(this)
            if (rem <= 0L) {
                completeSessionNatural()
                return
            }
            stateBadge.setText(R.string.focus_state_focus)
            stateBadge.setBackgroundResource(R.drawable.bg_tab_active)
            timerText.text = format(rem)
            timerText.setTextColor(getColor(R.color.primary))
            val used = Prefs.getBreaksUsed(this)
            val allowed = Prefs.getBreaksAllowed(this)
            breaksLeftText.text = if (allowed == 0) getString(R.string.focus_no_breaks)
                                   else getString(R.string.focus_breaks_left, allowed - used, allowed)
            val canBreak = allowed > 0 && used < allowed
            takeBreakBtn.isEnabled = canBreak
            takeBreakBtn.alpha = if (canBreak) 1f else 0.4f
        }
    }

    // ---------- Utilities ----------

    private fun format(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        val m = total / 60
        val s = total % 60
        return String.format(java.util.Locale.US, "%02d:%02d", m, s)
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }
}
