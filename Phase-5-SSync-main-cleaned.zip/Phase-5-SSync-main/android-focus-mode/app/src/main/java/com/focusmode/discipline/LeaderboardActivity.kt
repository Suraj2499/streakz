package com.focusmode.discipline

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.widget.ViewFlipper
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.coroutines.launch

/**
 * Leaderboard main screen with two top tabs: Public | Groups.
 * A Friends pill in the header opens FriendsActivity.
 *
 * Public tab: auto-grouped leaderboard (course · level · attempt) with podium + list + your-rank footer.
 * Groups tab: user's groups + Create/Join CTAs + empty state.
 */
class LeaderboardActivity : AppCompatActivity() {

    private enum class Tab { PUBLIC, GROUPS }

    private lateinit var tabPublic: TextView
    private lateinit var tabGroups: TextView
    private lateinit var flipper: ViewFlipper

    private lateinit var publicGroupLabel: TextView
    private lateinit var publicPodium: View
    private lateinit var publicList: LinearLayout
    private lateinit var publicMyRank: TextView

    private lateinit var createBtn: Button
    private lateinit var joinBtn: Button
    private lateinit var groupsList: LinearLayout
    private lateinit var groupsEmpty: LinearLayout

    private var currentTab = Tab.PUBLIC

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leaderboard)

        tabPublic = findViewById(R.id.tabPublic)
        tabGroups = findViewById(R.id.tabGroups)
        flipper = findViewById(R.id.tabFlipper)

        publicGroupLabel = findViewById(R.id.publicGroupLabel)
        publicPodium = findViewById(R.id.publicPodium)
        publicList = findViewById(R.id.publicListContainer)
        publicMyRank = findViewById(R.id.publicMyRank)

        createBtn = findViewById(R.id.createGroupBtn)
        joinBtn = findViewById(R.id.joinGroupBtn)
        groupsList = findViewById(R.id.groupsListContainer)
        groupsEmpty = findViewById(R.id.groupsEmpty)

        tabPublic.setOnClickListener { switchTab(Tab.PUBLIC) }
        tabGroups.setOnClickListener { switchTab(Tab.GROUPS) }
        createBtn.setOnClickListener { showCreateGroupDialog() }
        joinBtn.setOnClickListener { showJoinGroupDialog() }

        findViewById<TextView>(R.id.openFriendsBtn).setOnClickListener {
            startActivity(Intent(this, FriendsActivity::class.java))
        }

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        BottomNavHelper.setup(this, bottomNav, R.id.nav_leaderboard)
    }

    override fun onResume() {
        super.onResume()
        switchTab(currentTab, forceRender = true)
        // Async: refresh public leaderboard from Supabase and re-render if it succeeds.
        lifecycleScope.launch {
            val remote = LeaderboardRepo.fetchPublicLeaderboardFromBackend(this@LeaderboardActivity)
            if (remote != null && currentTab == Tab.PUBLIC) {
                renderPublicFromEntries(remote)
            }
        }
    }

    private fun switchTab(tab: Tab, forceRender: Boolean = false) {
        val changed = currentTab != tab
        currentTab = tab
        applyTabStyle(tabPublic, tab == Tab.PUBLIC)
        applyTabStyle(tabGroups, tab == Tab.GROUPS)

        if (changed || forceRender) {
            val target = if (tab == Tab.PUBLIC) 0 else 1
            if (flipper.displayedChild != target) flipper.displayedChild = target
        }

        if (tab == Tab.PUBLIC) renderPublic() else renderGroups()
    }

    private fun applyTabStyle(view: TextView, active: Boolean) {
        view.setBackgroundResource(if (active) R.drawable.bg_tab_active else R.drawable.bg_tab_inactive)
        view.setTextColor(getColor(if (active) R.color.black else R.color.text_secondary))
    }

    // ----- Public tab -----

    private fun renderPublic() {
        publicGroupLabel.text = LeaderboardRepo.getPublicGroupLabel(this)
        val entries = LeaderboardRepo.getPublicLeaderboard(this)
        renderPublicFromEntries(entries)
    }

    /** Render the Public tab from a pre-computed entry list (used by async backend refresh). */
    private fun renderPublicFromEntries(entries: List<LeaderboardEntry>) {
        publicGroupLabel.text = LeaderboardRepo.getPublicGroupLabel(this)
        LeaderboardUi.render(LayoutInflater.from(this), publicPodium, publicList, entries)
        val me = entries.firstOrNull { it.isCurrentUser }
        publicMyRank.text = if (me != null) {
            getString(R.string.lb_your_rank_score, me.rank, me.score)
        } else getString(R.string.lb_your_rank_none)
    }

    // ----- Groups tab -----

    private fun renderGroups() {
        groupsList.removeAllViews()
        val groups = LeaderboardRepo.getMyGroups(this)
        if (groups.isEmpty()) {
            groupsEmpty.visibility = View.VISIBLE
            return
        }
        groupsEmpty.visibility = View.GONE
        val inflater = LayoutInflater.from(this)
        groups.forEach { g ->
            val row = inflater.inflate(R.layout.item_group_row, groupsList, false)
            row.findViewById<TextView>(R.id.groupName).text = g.name
            row.findViewById<TextView>(R.id.groupCode).text = g.inviteCode
            val desc = row.findViewById<TextView>(R.id.groupDesc)
            if (g.description.isBlank()) desc.visibility = View.GONE
            else { desc.visibility = View.VISIBLE; desc.text = g.description }
            row.findViewById<TextView>(R.id.groupMeta).text =
                getString(R.string.lb_group_members_count, g.memberIds.size)
            row.setOnClickListener {
                val i = Intent(this, GroupDetailActivity::class.java)
                    .putExtra("group_id", g.id)
                startActivity(i)
            }
            groupsList.addView(row)
        }
    }

    // ----- Dialogs -----

    private fun showCreateGroupDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 16, 48, 0)
        }
        val nameIn = EditText(this).apply {
            hint = getString(R.string.lb_group_name_hint)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        }
        val descIn = EditText(this).apply {
            hint = getString(R.string.lb_group_desc_hint)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        container.addView(nameIn)
        container.addView(descIn)
        AlertDialog.Builder(this)
            .setTitle(R.string.lb_create_group)
            .setView(container)
            .setPositiveButton(R.string.lb_create) { _, _ ->
                val n = nameIn.text.toString().trim()
                if (n.isBlank()) {
                    Toast.makeText(this, R.string.lb_group_name_required, Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                // Server-first: creates the row on Supabase so joiners resolve to the same group.
                lifecycleScope.launch {
                    val g = LeaderboardRepo.createGroupSync(this@LeaderboardActivity, n, descIn.text.toString())
                    Toast.makeText(this@LeaderboardActivity,
                        getString(R.string.lb_group_created_fmt, g.inviteCode),
                        Toast.LENGTH_LONG).show()
                    renderGroups()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showJoinGroupDialog() {
        val input = EditText(this).apply {
            hint = getString(R.string.lb_invite_code_hint)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.lb_join_group)
            .setView(input)
            .setPositiveButton(R.string.lb_join) { _, _ ->
                val code = input.text.toString().trim().uppercase()
                if (code.isBlank()) {
                    Toast.makeText(this, R.string.lb_invite_code_required, Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                // Server-first: uses join_group_by_code RPC + fetches authoritative group.
                lifecycleScope.launch {
                    val g = LeaderboardRepo.joinGroupSync(this@LeaderboardActivity, code)
                    if (g != null) {
                        Toast.makeText(this@LeaderboardActivity,
                            getString(R.string.lb_joined_fmt, g.name), Toast.LENGTH_SHORT).show()
                        renderGroups()
                    } else {
                        Toast.makeText(this@LeaderboardActivity,
                            R.string.lb_join_failed, Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
