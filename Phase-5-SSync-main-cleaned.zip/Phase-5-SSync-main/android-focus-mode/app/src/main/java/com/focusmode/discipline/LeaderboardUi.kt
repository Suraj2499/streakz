package com.focusmode.discipline

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Renders a leaderboard (podium + list) into the provided views.
 * Used by LeaderboardActivity (Public tab), GroupDetailActivity, FriendsActivity.
 */
object LeaderboardUi {

    /**
     * Populates a podium include + a list container with entries.
     *  - podium: included view with podium cards (may be null if no podium is shown)
     *  - listContainer: vertical LinearLayout that receives the ranked list (position 4+)
     *  - entries: pre-ranked leaderboard
     *  - listFrom: rank (1-based) the list starts showing from (default 4: top 3 go to podium)
     */
    fun render(
        inflater: LayoutInflater,
        podium: View?,
        listContainer: LinearLayout,
        entries: List<LeaderboardEntry>,
        listFrom: Int = 4
    ) {
        listContainer.removeAllViews()
        if (podium != null) renderPodium(podium, entries)
        val listRows = entries.filter { it.rank >= listFrom }
        listRows.forEach { entry ->
            val row = inflater.inflate(R.layout.item_leader_row, listContainer, false)
            bindRow(row, entry)
            listContainer.addView(row)
        }
        // If fewer than 4 entries, hide podium slots that would be empty by clearing text.
    }

    fun bindRow(row: View, entry: LeaderboardEntry) {
        val rankBadge = row.findViewById<TextView>(R.id.rankBadge)
        val avatarBg = row.findViewById<View>(R.id.avatarBg)
        val avatarLetter = row.findViewById<TextView>(R.id.avatarLetter)
        val name = row.findViewById<TextView>(R.id.userName)
        val sub = row.findViewById<TextView>(R.id.userSub)
        val score = row.findViewById<TextView>(R.id.userScore)

        rankBadge.text = entry.rank.toString().padStart(2, '0')
        when (entry.rank) {
            1 -> rankBadge.setBackgroundResource(R.drawable.bg_rank_gold)
            2 -> rankBadge.setBackgroundResource(R.drawable.bg_rank_silver)
            3 -> rankBadge.setBackgroundResource(R.drawable.bg_rank_bronze)
            else -> rankBadge.setBackgroundResource(R.drawable.bg_avatar_circle)
        }
        avatarLetter.text = entry.avatarLetter
        name.text = entry.name
        sub.visibility = View.GONE
        score.text = entry.score.toString()

        if (entry.isCurrentUser) {
            row.setBackgroundResource(R.drawable.bg_row_me)
            val ctx = row.context
            name.setTextColor(ctx.getColor(R.color.primary))
            avatarBg.setBackgroundResource(R.drawable.bg_avatar_gold)
        } else {
            row.setBackgroundResource(R.drawable.bg_row)
            avatarBg.setBackgroundResource(R.drawable.bg_avatar_circle)
        }
    }

    private fun renderPodium(podium: View, entries: List<LeaderboardEntry>) {
        val slot1 = podium.findViewById<ViewGroup>(R.id.podiumSlot1)
        val slot2 = podium.findViewById<ViewGroup>(R.id.podiumSlot2)
        val slot3 = podium.findViewById<ViewGroup>(R.id.podiumSlot3)
        val p1 = entries.firstOrNull { it.rank == 1 }
        val p2 = entries.firstOrNull { it.rank == 2 }
        val p3 = entries.firstOrNull { it.rank == 3 }

        bindSlot(podium, R.id.pd1Letter, R.id.pd1Name, R.id.pd1Score, p1, slot1)
        bindSlot(podium, R.id.pd2Letter, R.id.pd2Name, R.id.pd2Score, p2, slot2)
        bindSlot(podium, R.id.pd3Letter, R.id.pd3Name, R.id.pd3Score, p3, slot3)
    }

    private fun bindSlot(
        podium: View, letterId: Int, nameId: Int, scoreId: Int,
        entry: LeaderboardEntry?, slot: ViewGroup
    ) {
        val letter = podium.findViewById<TextView>(letterId)
        val nameView = podium.findViewById<TextView>(nameId)
        val scoreView = podium.findViewById<TextView>(scoreId)
        if (entry == null) {
            slot.visibility = View.INVISIBLE
            return
        }
        slot.visibility = View.VISIBLE
        letter.text = entry.avatarLetter
        nameView.text = entry.name
        scoreView.text = entry.score.toString()
    }
}
