package com.focusmode.discipline

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

/**
 * Home / dashboard screen per latest mockup:
 *  - Welcome + name
 *  - Combined stats card (streak / today focus / done)
 *  - Your To-Do section with three tabs (Today / Pending / Revisions)
 *  - Empty state with "Plan from Lectures" CTA
 *
 * Tabs:
 *  - Today     : tasks with date == today
 *  - Pending   : tasks older than 2 days that are still "pending"
 *  - Revisions : placeholder (always empty for now)
 */
class DashboardActivity : AppCompatActivity() {

    private enum class Tab { TODAY, PENDING, REVISIONS }

    private lateinit var tabTodayView: TextView
    private lateinit var tabPendingView: TextView
    private lateinit var tabRevisionsView: TextView
    private lateinit var tasksContainer: LinearLayout
    private lateinit var emptyState: LinearLayout
    private lateinit var emptyText: TextView
    private lateinit var planBtn: Button
    private lateinit var addFab: TextView

    private lateinit var statStreakDays: TextView
    private lateinit var statTodayHours: TextView
    private lateinit var statTodayDone: TextView
    private lateinit var statTotalHours: TextView
    private lateinit var statPendingTasks: TextView
    private lateinit var statPendingRevisions: TextView
    private lateinit var statDaysLeft: TextView
    private lateinit var statSyllabusPct: TextView
    private lateinit var syllabusProgressBar: android.widget.ProgressBar
    private lateinit var headerName: TextView

    private var currentTab: Tab = Tab.TODAY

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        headerName = findViewById(R.id.headerName)
        statStreakDays = findViewById(R.id.statStreakDays)
        statTodayHours = findViewById(R.id.statTodayHours)
        statTodayDone = findViewById(R.id.statTodayDone)
        statTotalHours = findViewById(R.id.statTotalHours)
        statPendingTasks = findViewById(R.id.statPendingTasks)
        statPendingRevisions = findViewById(R.id.statPendingRevisions)
        statDaysLeft = findViewById(R.id.statDaysLeft)
        statSyllabusPct = findViewById(R.id.statSyllabusPct)
        syllabusProgressBar = findViewById(R.id.syllabusProgressBar)

        tabTodayView = findViewById(R.id.tabToday)
        tabPendingView = findViewById(R.id.tabPending)
        tabRevisionsView = findViewById(R.id.tabRevisions)
        tasksContainer = findViewById(R.id.tasksContainer)
        emptyState = findViewById(R.id.emptyState)
        emptyText = findViewById(R.id.emptyText)
        planBtn = findViewById(R.id.planBtn)
        addFab = findViewById(R.id.addTaskFab)

        tabTodayView.setOnClickListener { switchTab(Tab.TODAY) }
        tabPendingView.setOnClickListener { switchTab(Tab.PENDING) }
        tabRevisionsView.setOnClickListener { switchTab(Tab.REVISIONS) }

        planBtn.setOnClickListener { openPlanFromLectures() }
        addFab.setOnClickListener { openPlanFromLectures() }

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        BottomNavHelper.setup(this, bottomNav, R.id.nav_dashboard)
    }

    override fun onResume() {
        super.onResume()
        renderHeader()
        renderStats()
        switchTab(currentTab)
    }

    // ---------- Render: header & stats ----------

    private fun renderHeader() {
        val user = UserPrefs.getProfile(this)
        headerName.text = user.name.ifBlank { getString(R.string.profile_no_name) }
    }

    private fun renderStats() {
        val streak = TaskPrefs.getStreak(this)
        val todayMs = TaskPrefs.getTodayFocusMs(this)
        val totalHours = TaskPrefs.getTotalFocusHours(this)
        val done = TaskPrefs.getTodayDoneCount(this)
        val pendingTasks = TaskPrefs.getPendingCount(this)
        val pendingRevisions = SyllabusPrefs.getRevisionsDue(this).size
        val daysLeft = UserPrefs.getDaysLeft(this)
        val syllabusPct = SyllabusPrefs.getOverallProgressPercent(this)

        statStreakDays.text = getString(R.string.dash_days_fmt, streak)
        statTodayHours.text = formatHoursOneDecimal(todayMs)
        statTodayDone.text = done.toString()
        statTotalHours.text = getString(R.string.dash_hours_fmt, totalHours)
        statPendingTasks.text = pendingTasks.toString()
        statPendingRevisions.text = pendingRevisions.toString()
        statDaysLeft.text = daysLeft?.coerceAtLeast(0)?.toString() ?: getString(R.string.dash_na)
        statSyllabusPct.text = getString(R.string.dash_percent_fmt, syllabusPct)
        syllabusProgressBar.progress = syllabusPct
    }

    // ---------- Render: tabs ----------

    private fun switchTab(tab: Tab) {
        currentTab = tab
        val todayCount = TaskPrefs.getTodayTasks(this).size
        val pendingCount = TaskPrefs.getPendingTasks(this).size
        val revisionsDue = SyllabusPrefs.getRevisionsDue(this)

        tabTodayView.text = getString(R.string.dash_tab_today, todayCount)
        tabPendingView.text = getString(R.string.dash_tab_pending, pendingCount)
        tabRevisionsView.text = getString(R.string.dash_tab_revisions, revisionsDue.size)

        applyTabStyle(tabTodayView, tab == Tab.TODAY)
        applyTabStyle(tabPendingView, tab == Tab.PENDING)
        applyTabStyle(tabRevisionsView, tab == Tab.REVISIONS)

        if (tab == Tab.REVISIONS) {
            renderRevisionsList(revisionsDue)
            return
        }
        val items = when (tab) {
            Tab.TODAY -> TaskPrefs.getTodayTasks(this)
            Tab.PENDING -> TaskPrefs.getPendingTasks(this)
            Tab.REVISIONS -> emptyList()
        }
        renderTaskList(items, tab)
    }

    private fun renderRevisionsList(items: List<RevisionItem>) {
        tasksContainer.removeAllViews()
        if (items.isEmpty()) {
            tasksContainer.visibility = View.GONE
            emptyState.visibility = View.VISIBLE
            emptyText.text = getString(R.string.dash_empty_revisions)
            planBtn.visibility = View.GONE
            return
        }
        emptyState.visibility = View.GONE
        tasksContainer.visibility = View.VISIBLE
        val inflater = LayoutInflater.from(this)
        items.forEach { rev ->
            val row = inflater.inflate(R.layout.item_task, tasksContainer, false)
            val check = row.findViewById<CheckBox>(R.id.taskCheck)
            val title = row.findViewById<TextView>(R.id.taskTitle)
            val status = row.findViewById<TextView>(R.id.taskStatus)
            title.text = getString(R.string.dash_revision_of, rev.chapterName)
            check.setOnCheckedChangeListener(null)
            check.isChecked = false
            status.text = getString(R.string.dash_revision_due, rev.scheduledDate)
            status.setTextColor(getColor(R.color.text_muted))
            val action = View.OnClickListener {
                androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle(R.string.revision_action_title)
                    .setMessage(getString(R.string.dash_revision_of, rev.chapterName))
                    .setPositiveButton(R.string.revision_action_mark_done) { _, _ ->
                        SyllabusPrefs.completeRevision(this, rev.id)
                        android.widget.Toast.makeText(
                            this, R.string.revision_marked_done, android.widget.Toast.LENGTH_SHORT
                        ).show()
                        renderStats()
                        switchTab(currentTab)
                    }
                    .setNegativeButton(R.string.revision_action_dismiss, null)
                    .show()
            }
            row.setOnClickListener(action)
            check.setOnClickListener(action)
            tasksContainer.addView(row)
        }
    }

    private fun applyTabStyle(view: TextView, active: Boolean) {
        view.setBackgroundResource(if (active) R.drawable.bg_tab_active else R.drawable.bg_tab_inactive)
        view.setTextColor(
            getColor(if (active) R.color.black else R.color.text_secondary)
        )
    }

    // ---------- Render: task list / empty state ----------

    private fun renderTaskList(items: List<TaskItem>, tab: Tab) {
        tasksContainer.removeAllViews()
        if (items.isEmpty()) {
            tasksContainer.visibility = View.GONE
            emptyState.visibility = View.VISIBLE
            emptyText.text = when (tab) {
                Tab.TODAY -> getString(R.string.dash_empty_today)
                Tab.PENDING -> getString(R.string.dash_empty_pending)
                Tab.REVISIONS -> getString(R.string.dash_empty_revisions)
            }
            // "Plan from Lectures" only makes sense on the Today tab
            planBtn.visibility = if (tab == Tab.TODAY) View.VISIBLE else View.GONE
            return
        }
        emptyState.visibility = View.GONE
        tasksContainer.visibility = View.VISIBLE
        val inflater = LayoutInflater.from(this)
        items.forEach { task ->
            val row = inflater.inflate(R.layout.item_task, tasksContainer, false)
            val check = row.findViewById<CheckBox>(R.id.taskCheck)
            val title = row.findViewById<TextView>(R.id.taskTitle)
            val status = row.findViewById<TextView>(R.id.taskStatus)
            title.text = task.title
            val isDone = task.status == "completed"
            check.setOnCheckedChangeListener(null)
            check.isChecked = isDone
            title.paintFlags = if (isDone) {
                title.paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
            } else {
                title.paintFlags and android.graphics.Paint.STRIKE_THRU_TEXT_FLAG.inv()
            }
            status.text = if (isDone) getString(R.string.task_completed) else task.date
            status.setTextColor(
                getColor(if (isDone) R.color.primary else R.color.text_muted)
            )
            val toggle = View.OnClickListener {
                if (task.status == "completed") {
                    TaskPrefs.markPending(this, task.id)
                } else {
                    TaskPrefs.markCompleted(this, task.id)
                }
                renderStats()
                switchTab(currentTab)
            }
            row.setOnClickListener(toggle)
            check.setOnClickListener(toggle)
            tasksContainer.addView(row)
        }
    }

    // ---------- Helpers ----------

    /**
     * "Plan from Lectures" / FAB: both route to the Lectures screen where the
     * syllabus/lecture picker will live (described in next prompt).
     */
    private fun openPlanFromLectures() {
        startActivity(Intent(this, LecturesActivity::class.java))
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }

    private fun formatHoursOneDecimal(ms: Long): String {
        val hours = ms.toDouble() / (1000.0 * 60 * 60)
        return String.format(java.util.Locale.US, "%.1fh", hours)
    }
}
