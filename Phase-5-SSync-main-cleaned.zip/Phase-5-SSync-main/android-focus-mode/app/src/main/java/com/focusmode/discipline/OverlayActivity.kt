package com.focusmode.discipline

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Two-stage interruption shown by AppMonitorService when a blocked app is opened
 * during a focus session.
 *
 * Stage 1: "You are breaking your focus session"  -> Continue Focus / End Session
 * Stage 2: "This will break your progress"        -> Go Back / End Anyway (5s delay)
 *
 * "Continue Focus" / "Go Back"  -> back to Home, focus stays active
 * "End Anyway" (after 5s)       -> mark session broken + add backlog task + stop service
 */
class OverlayActivity : AppCompatActivity() {

    companion object { const val EXTRA_BLOCKED_PKG = "extra_blocked_pkg" }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var stage1: LinearLayout
    private lateinit var stage2: LinearLayout
    private lateinit var endAnywayBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true); setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContentView(R.layout.activity_overlay)

        stage1 = findViewById(R.id.stage1)
        stage2 = findViewById(R.id.stage2)

        val blockedPkg = intent.getStringExtra(EXTRA_BLOCKED_PKG) ?: ""
        findViewById<TextView>(R.id.overlayInfo).text = "Blocked app: $blockedPkg"

        findViewById<Button>(R.id.s1ContinueBtn).setOnClickListener { goHome() }
        findViewById<Button>(R.id.s1EndBtn).setOnClickListener { showStage2() }
        findViewById<Button>(R.id.s2BackBtn).setOnClickListener { showStage1() }

        endAnywayBtn = findViewById(R.id.s2EndAnywayBtn)
        endAnywayBtn.setOnClickListener { finalizeEnd() }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* no-op — force explicit choice */ }

    private fun showStage1() {
        handler.removeCallbacksAndMessages(null)
        stage1.visibility = View.VISIBLE
        stage2.visibility = View.GONE
    }

    private fun showStage2() {
        stage1.visibility = View.GONE
        stage2.visibility = View.VISIBLE
        startDelayCountdown()
    }

    private fun startDelayCountdown() {
        endAnywayBtn.isEnabled = false
        var remaining = 5
        endAnywayBtn.text = getString(R.string.focus_exit_hold, remaining)
        val tick = object : Runnable {
            override fun run() {
                remaining--
                if (remaining <= 0) {
                    endAnywayBtn.isEnabled = true
                    endAnywayBtn.text = getString(R.string.overlay_s2_end_anyway)
                } else {
                    endAnywayBtn.text = getString(R.string.focus_exit_hold, remaining)
                    handler.postDelayed(this, 1000)
                }
            }
        }
        handler.postDelayed(tick, 1000)
    }

    private fun goHome() {
        val home = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(home)
        finish()
    }

    private fun finalizeEnd() {
        val plannedMinutes = (Prefs.getTotalMs(this) / 60_000L).toInt().coerceAtLeast(1)
        Prefs.endSessionBroken(this)
        TaskPrefs.endFocusSession(this)
        stopService(Intent(this, AppMonitorService::class.java))
        // Add a backlog task dated 3 days ago so it lands directly in the Pending tab.
        TaskPrefs.addTask(
            this,
            getString(R.string.focus_backlog_task, plannedMinutes),
            date = threeDaysAgo()
        )
        finish()
    }

    private fun threeDaysAgo(): String {
        val cal = java.util.Calendar.getInstance()
        cal.add(java.util.Calendar.DAY_OF_MONTH, -3)
        return java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(cal.time)
    }
}
