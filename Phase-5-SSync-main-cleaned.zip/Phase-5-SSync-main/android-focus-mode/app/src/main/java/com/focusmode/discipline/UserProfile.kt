package com.focusmode.discipline

/**
 * Immutable snapshot of the local user profile.
 * Matches the shape we'll sync to the backend in the future.
 *
 * Field names match the future API contract — do NOT rename carelessly.
 */
data class UserProfile(
    val userId: String,
    val name: String,
    val email: String,
    val course: String?,      // "CA" | "CS" | "CMA"
    val level: String?,       // "Foundation" | "Inter" | "Final"
    val examMonth: String?,   // "MM/YYYY" e.g. "05/2026"
    val isLoggedIn: Boolean,
    val onboardingCompleted: Boolean,
    val lastSyncedAt: Long    // epoch millis, 0 until first backend sync
)
