package com.focusmode.discipline.sync

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.focusmode.discipline.net.AuthManager
import com.focusmode.discipline.net.BackendRepo
import com.focusmode.discipline.net.dto.GroupDto

/**
 * Drains SyncQueue and uploads events to Supabase one-by-one. Called by
 * WorkManager with network constraints, so we assume the device is online
 * when this runs.
 *
 * Policy:
 *   - No session  → Success (retry on next login)
 *   - Event ok    → remove from queue, continue
 *   - Event fails → Retry (WorkManager backoff)
 */
class SyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        if (!AuthManager.hasSession()) {
            Log.d(TAG, "No Supabase session — skipping sync")
            return Result.success()
        }
        val events = SyncQueue.snapshot(ctx)
        if (events.isEmpty()) return Result.success()

        var anyFailed = false
        for (event in events) {
            val ok = runEvent(event)
            if (ok) SyncQueue.removeByKey(ctx, event.key)
            else { anyFailed = true; Log.w(TAG, "Event failed: ${event::class.simpleName}") ; break }
        }
        return if (anyFailed) Result.retry() else Result.success()
    }

    private suspend fun runEvent(event: SyncEvent): Boolean = when (event) {
        is SyncEvent.UserUpsert -> BackendRepo.upsertUser(event.user).isSuccess
        is SyncEvent.ProgressUpsert -> BackendRepo.upsertProgress(event.progress).isSuccess
        is SyncEvent.GroupCreate -> BackendRepo.createGroup(
            GroupDto(
                id = event.id, name = event.name, description = event.description,
                inviteCode = event.inviteCode, ownerId = event.ownerId
            )
        ).fold(onSuccess = { true }, onFailure = { isIdempotentConflict(it) })
        is SyncEvent.GroupJoin -> BackendRepo.joinGroupByCode(event.code)
            .fold(onSuccess = { true }, onFailure = { false })
        is SyncEvent.GroupLeave -> BackendRepo.leaveGroup(event.groupId, event.userId)
            .fold(onSuccess = { true }, onFailure = { isIdempotentConflict(it) })
        is SyncEvent.FriendAdd -> BackendRepo.addFriend(event.userId, event.friendId).isSuccess
        is SyncEvent.FriendRemove -> BackendRepo.removeFriend(event.userId, event.friendId)
            .fold(onSuccess = { true }, onFailure = { isIdempotentConflict(it) })
    }

    /**
     * Treat "already exists / already deleted" errors as success so we don't
     * retry forever. Postgrest returns 23505 for unique-violation and 404 for
     * no-op deletes; we approximate by message.
     */
    private fun isIdempotentConflict(t: Throwable): Boolean {
        val m = t.message?.lowercase().orEmpty()
        return "duplicate" in m || "already exists" in m || "unique" in m || "conflict" in m
    }

    companion object { private const val TAG = "SyncWorker" }
}
