package com.focusmode.discipline

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * Chapters inside a Subject / Sub-subject.
 * Receives full context (course / level / group / subject / subsubject) via Intent extras.
 *
 * Supports:
 *  - Search filter
 *  - "Mark Done" shortcut (manual chapter completion + schedules revisions)
 *  - Self Study and Watch Lectures flows
 *  - "Watch Lectures" auto-populates lectures from subchapters when available.
 */
class ChaptersActivity : AppCompatActivity() {

    private lateinit var container: LinearLayout
    private lateinit var search: EditText
    private lateinit var chapters: List<Chapter>

    private var course: String = ""
    private var level: String = ""
    private var group: String? = null
    private var subject: String = ""
    private var subsubject: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chapters)

        course = intent.getStringExtra(SyllabusListActivity.EXTRA_COURSE) ?: ""
        level = intent.getStringExtra(SyllabusListActivity.EXTRA_LEVEL) ?: ""
        group = intent.getStringExtra(SyllabusListActivity.EXTRA_GROUP)
        subject = intent.getStringExtra(SyllabusListActivity.EXTRA_SUBJECT) ?: ""
        subsubject = intent.getStringExtra(SyllabusListActivity.EXTRA_SUBSUBJECT)

        findViewById<TextView>(R.id.chaptersTitle).text =
            intent.getStringExtra("subject_name") ?: subsubject ?: subject

        container = findViewById(R.id.chaptersContainer)
        search = findViewById(R.id.chaptersSearch)
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { render(s?.toString().orEmpty()) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }

    override fun onResume() {
        super.onResume()
        chapters = SyllabusPrefs.getChaptersForContext(this, course, level, group, subject, subsubject)
        render(search.text.toString())
    }

    private fun render(query: String) {
        container.removeAllViews()
        val q = query.trim().lowercase()
        val list = if (q.isEmpty()) chapters
                   else chapters.filter { it.name.lowercase().contains(q) }

        if (list.isEmpty()) {
            val empty = TextView(this).apply {
                text = getString(R.string.syllabus_no_chapters)
                setTextColor(getColor(R.color.text_muted))
                setPadding(0, 40, 0, 0)
            }
            container.addView(empty)
            return
        }

        val inflater = LayoutInflater.from(this)
        list.forEach { chapter ->
            val row = inflater.inflate(R.layout.item_chapter, container, false)
            row.findViewById<TextView>(R.id.chapterName).text = chapter.name
            val statusText = row.findViewById<TextView>(R.id.chapterStatusText)
            val dot = row.findViewById<View>(R.id.chapterStatusDot)
            when (chapter.status) {
                "completed" -> {
                    statusText.text = getString(R.string.status_completed)
                    statusText.setTextColor(0xFF4CAF50.toInt())
                    dot.setBackgroundResource(R.drawable.dot_green)
                }
                "in-progress" -> {
                    statusText.text = getString(R.string.status_in_progress)
                    statusText.setTextColor(0xFFFFC107.toInt())
                    dot.setBackgroundResource(R.drawable.dot_yellow)
                }
                else -> {
                    statusText.text = getString(R.string.status_pending)
                    statusText.setTextColor(0xFFF44336.toInt())
                    dot.setBackgroundResource(R.drawable.dot_red)
                }
            }
            row.setOnClickListener { onChapterClicked(chapter) }

            val markDoneBtn = row.findViewById<Button>(R.id.markDoneBtn)
            if (chapter.status == "completed") {
                markDoneBtn.visibility = View.GONE
            } else {
                markDoneBtn.visibility = View.VISIBLE
                markDoneBtn.setOnClickListener { confirmMarkChapterDone(chapter) }
            }

            row.findViewById<Button>(R.id.addTodoBtn).setOnClickListener {
                TaskPrefs.addTask(this, chapter.name)
                Toast.makeText(this, R.string.syllabus_added_to_todo, Toast.LENGTH_SHORT).show()
            }
            container.addView(row)
        }
    }

    private fun confirmMarkChapterDone(chapter: Chapter) {
        AlertDialog.Builder(this)
            .setTitle(R.string.chapter_mark_done_confirm_title)
            .setMessage(R.string.chapter_mark_done_confirm_msg)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                SyllabusPrefs.updateChapterStatus(this, chapter.id, "completed")
                SyllabusPrefs.scheduleRevisionsForChapter(this, chapter.id)
                Toast.makeText(this, R.string.chapter_marked_done, Toast.LENGTH_SHORT).show()
                chapters = SyllabusPrefs.getChaptersForContext(this, course, level, group, subject, subsubject)
                render(search.text.toString())
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---------- Study flow ----------

    private fun onChapterClicked(chapter: Chapter) {
        AlertDialog.Builder(this)
            .setTitle(chapter.name)
            .setItems(arrayOf(getString(R.string.sy_self_study), getString(R.string.sy_watch_lectures))) { _, which ->
                when (which) {
                    0 -> promptDurationAndStart(chapter, isLecture = false)
                    1 -> openLectures(chapter)
                }
            }
            .show()
    }

    private fun promptDurationAndStart(chapter: Chapter, isLecture: Boolean, lectureId: String? = null) {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = getString(R.string.sy_duration_hint)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.sy_enter_duration)
            .setView(input)
            .setPositiveButton(R.string.sy_start) { _, _ ->
                val mins = input.text.toString().toIntOrNull() ?: 0
                if (mins <= 0) {
                    Toast.makeText(this, R.string.sy_invalid_duration, Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                SyllabusPrefs.updateChapterStatus(this, chapter.id, "in-progress")
                val intent = Intent(this, FocusTimerActivity::class.java).apply {
                    putExtra("duration_ms", mins.toLong() * 60_000L)
                    putExtra("label", chapter.name + if (isLecture) " — Lecture" else "")
                    putExtra("chapter_id", chapter.id)
                    putExtra("lecture_id", lectureId ?: "")
                    putExtra("is_lecture", isLecture)
                }
                startActivity(intent)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /**
     * Opens the lecture list for a chapter.
     * - If the chapter has subchapters in the JSON, auto-populate lectures from those names
     *   and skip the "enter lecture count" prompt.
     * - Otherwise, fall back to prompting the user for a lecture count.
     */
    private fun openLectures(chapter: Chapter) {
        val subchapters = SyllabusLoader.getSubchapters(
            this, course, level, group, subject, subsubject, chapter.name
        )
        if (subchapters.isNotEmpty()) {
            SyllabusPrefs.ensureLecturesFromSubchapters(this, chapter.id, subchapters)
            startActivity(
                Intent(this, LecturesListActivity::class.java)
                    .putExtra("chapter_id", chapter.id)
                    .putExtra("chapter_name", chapter.name)
                    .putStringArrayListExtra("subchapter_names", ArrayList(subchapters))
            )
            return
        }
        // Existing flow: chapter has no subchapters declared, prompt for a count.
        val existing = chapter.totalLectures
        val existingLectures = SyllabusPrefs.getLecturesForChapter(this, chapter.id)
        if (existing > 0 && existingLectures.isNotEmpty()) {
            Toast.makeText(this, R.string.sy_lectures_remembered, Toast.LENGTH_SHORT).show()
            startActivity(
                Intent(this, LecturesListActivity::class.java)
                    .putExtra("chapter_id", chapter.id)
                    .putExtra("chapter_name", chapter.name)
            )
            return
        }
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = getString(R.string.sy_lectures_hint)
            if (existing > 0) setText(existing.toString())
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.sy_enter_lecture_count)
            .setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val n = input.text.toString().toIntOrNull() ?: 0
                if (n <= 0) {
                    Toast.makeText(this, R.string.sy_invalid_count, Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                SyllabusPrefs.generateLecturesForChapter(this, chapter.id, n)
                startActivity(
                    Intent(this, LecturesListActivity::class.java)
                        .putExtra("chapter_id", chapter.id)
                        .putExtra("chapter_name", chapter.name)
                )
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
