package com.focusmode.discipline

import android.app.Activity
import android.content.Intent
import com.google.android.material.bottomnavigation.BottomNavigationView

/** Wires the 5-tab BottomNavigationView across top-level screens. */
object BottomNavHelper {
    fun setup(activity: Activity, bottomNav: BottomNavigationView, currentItemId: Int) {
        bottomNav.selectedItemId = currentItemId
        bottomNav.setOnItemSelectedListener { item ->
            if (item.itemId == currentItemId) return@setOnItemSelectedListener true
            val target = when (item.itemId) {
                R.id.nav_dashboard -> DashboardActivity::class.java
                R.id.nav_lectures -> LecturesActivity::class.java
                R.id.nav_focus -> MainActivity::class.java
                R.id.nav_leaderboard -> LeaderboardActivity::class.java
                R.id.nav_profile -> ProfileActivity::class.java
                else -> return@setOnItemSelectedListener false
            }
            activity.startActivity(
                Intent(activity, target)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            )
            @Suppress("DEPRECATION")
            activity.overridePendingTransition(0, 0)
            true
        }
    }
}
