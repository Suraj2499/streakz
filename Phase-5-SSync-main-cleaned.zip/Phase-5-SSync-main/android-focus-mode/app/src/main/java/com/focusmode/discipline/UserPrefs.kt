package com.focusmode.discipline

import android.content.Context
import android.content.SharedPreferences
import java.util.UUID

/**
 * SharedPreferences wrapper for the user profile + auth + onboarding state.
 *
 * Kept in a SEPARATE preferences file from Prefs (which stores blocking state)
 * so the two concerns stay isolated and the blocking logic is untouched.
 *
 * Key naming convention: "user_*" so a future migration to Room / backend DTOs
 * can map 1:1 without guessing.
 */
object UserPrefs {
    private const val FILE = "user_prefs"

    private const val KEY_USER_ID = "user_id"
    private const val KEY_NAME = "user_name"
    private const val KEY_EMAIL = "user_email"
    private const val KEY_COURSE = "user_course"
    private const val KEY_LEVEL = "user_level"
    private const val KEY_EXAM_MONTH = "user_exam_month"
    private const val KEY_IS_LOGGED_IN = "user_is_logged_in"
    private const val KEY_ONBOARDING_DONE = "user_onboarding_completed"
    private const val KEY_LAST_SYNCED_AT = "user_last_synced_at"

    private fun sp(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ------- Read helpers -------

    fun isLoggedIn(ctx: Context): Boolean = sp(ctx).getBoolean(KEY_IS_LOGGED_IN, false)

    fun isOnboardingCompleted(ctx: Context): Boolean =
        sp(ctx).getBoolean(KEY_ONBOARDING_DONE, false)

    fun getEmail(ctx: Context): String? = sp(ctx).getString(KEY_EMAIL, null)

    fun getProfile(ctx: Context): UserProfile {
        val s = sp(ctx)
        return UserProfile(
            userId = s.getString(KEY_USER_ID, "") ?: "",
            name = s.getString(KEY_NAME, "") ?: "",
            email = s.getString(KEY_EMAIL, "") ?: "",
            course = s.getString(KEY_COURSE, null),
            level = s.getString(KEY_LEVEL, null),
            examMonth = s.getString(KEY_EXAM_MONTH, null),
            isLoggedIn = s.getBoolean(KEY_IS_LOGGED_IN, false),
            onboardingCompleted = s.getBoolean(KEY_ONBOARDING_DONE, false),
            lastSyncedAt = s.getLong(KEY_LAST_SYNCED_AT, 0L)
        )
    }

    // ------- Auth -------

    /**
     * Signup: create a brand new userId, save name + email, mark logged in.
     */
    fun signup(ctx: Context, name: String, email: String) {
        sp(ctx).edit()
            .putString(KEY_USER_ID, UUID.randomUUID().toString())
            .putString(KEY_NAME, name.trim())
            .putString(KEY_EMAIL, email.trim())
            .putBoolean(KEY_IS_LOGGED_IN, true)
            // New user → onboarding still required.
            .putBoolean(KEY_ONBOARDING_DONE, false)
            .apply()
    }

    /**
     * Login-by-email (MVP).
     * - If the stored email matches, we just flip isLoggedIn=true, preserving everything else.
     * - Otherwise we treat it as a fresh local account with an empty name until profile is edited.
     */
    fun loginByEmail(ctx: Context, email: String) {
        val s = sp(ctx)
        val stored = s.getString(KEY_EMAIL, null)?.trim()?.lowercase()
        val incoming = email.trim()
        val editor = s.edit()
        if (stored != null && stored == incoming.lowercase()) {
            editor.putBoolean(KEY_IS_LOGGED_IN, true).apply()
        } else {
            editor
                .putString(KEY_USER_ID, UUID.randomUUID().toString())
                .putString(KEY_NAME, "")
                .putString(KEY_EMAIL, incoming)
                .putBoolean(KEY_IS_LOGGED_IN, true)
                .putBoolean(KEY_ONBOARDING_DONE, false)
                .remove(KEY_COURSE)
                .remove(KEY_LEVEL)
                .remove(KEY_EXAM_MONTH)
                .apply()
        }
    }

    fun logout(ctx: Context) {
        sp(ctx).edit().putBoolean(KEY_IS_LOGGED_IN, false).apply()
    }

    /**
     * Replace identity fields atomically — used after Supabase sign-up / sign-in.
     * Keeps onboarding/course/level intact if the email matches the stored one.
     */
    fun replaceIdentity(ctx: Context, userId: String, name: String, email: String) {
        val s = sp(ctx)
        val storedEmail = s.getString(KEY_EMAIL, null)?.trim()?.lowercase()
        val incoming = email.trim()
        val editor = s.edit()
            .putString(KEY_USER_ID, userId)
            .putString(KEY_NAME, name)
            .putString(KEY_EMAIL, incoming)
            .putBoolean(KEY_IS_LOGGED_IN, true)
        if (storedEmail != null && storedEmail != incoming.lowercase()) {
            // Different user on this device — wipe onboarding & course selections.
            editor.putBoolean(KEY_ONBOARDING_DONE, false)
                .remove(KEY_COURSE).remove(KEY_LEVEL).remove(KEY_EXAM_MONTH)
        }
        editor.apply()
    }

    /** Populate local profile from a server row (after sign-in pulls the user). */
    fun hydrateFromRemote(
        ctx: Context, userId: String, name: String, email: String,
        course: String?, level: String?, attempt: String?
    ) {
        val editor = sp(ctx).edit()
            .putString(KEY_USER_ID, userId)
            .putString(KEY_NAME, name)
            .putString(KEY_EMAIL, email.trim())
            .putBoolean(KEY_IS_LOGGED_IN, true)
        if (course != null) editor.putString(KEY_COURSE, course)
        if (level != null) editor.putString(KEY_LEVEL, level)
        // `attempt` is a label like "May 2026"; we do NOT overwrite examMonth since
        // that's stored as "MM/yyyy" locally. The SyncManager rebuilds attempt on upload.
        val hasProfile = !course.isNullOrBlank() && !level.isNullOrBlank()
        if (hasProfile) editor.putBoolean(KEY_ONBOARDING_DONE, true)
        editor.apply()
    }

    // ------- Onboarding -------

    fun saveCourse(ctx: Context, course: String) {
        sp(ctx).edit().putString(KEY_COURSE, course).apply()
    }

    fun saveLevel(ctx: Context, level: String) {
        sp(ctx).edit().putString(KEY_LEVEL, level).apply()
    }

    fun saveExamMonth(ctx: Context, monthYear: String) {
        sp(ctx).edit().putString(KEY_EXAM_MONTH, monthYear).apply()
    }

    fun markOnboardingCompleted(ctx: Context) {
        sp(ctx).edit().putBoolean(KEY_ONBOARDING_DONE, true).apply()
        // Order matters: profile first (so users.course/level/attempt are populated),
        // then progress (so the leaderboard trigger reads those fields and publishes a row).
        runCatching { com.focusmode.discipline.sync.SyncManager.syncProfileFromLocal(ctx) }
        runCatching { com.focusmode.discipline.sync.SyncManager.syncProgressFromLocal(ctx) }
    }

    // ------- Future backend sync hook -------

    /**
     * Call this after the profile has been successfully pushed to the backend.
     * Not used yet; it's here so the future sync layer has a well-named seam.
     */
    fun markSynced(ctx: Context, timestampMillis: Long = System.currentTimeMillis()) {
        sp(ctx).edit().putLong(KEY_LAST_SYNCED_AT, timestampMillis).apply()
    }

    // ------- Analytics: exam countdown -------

    /**
     * Returns days-left until the configured exam month (end of month), or null if not set.
     * Stored format is "MM/yyyy". We assume the exam happens on the 1st of that month.
     */
    fun getDaysLeft(ctx: Context): Int? {
        val raw = sp(ctx).getString(KEY_EXAM_MONTH, null) ?: return null
        if (raw.length != 7 || raw[2] != '/') return null
        val mm = raw.substring(0, 2).toIntOrNull() ?: return null
        val yyyy = raw.substring(3, 7).toIntOrNull() ?: return null
        val target = java.util.Calendar.getInstance().apply {
            clear()
            set(java.util.Calendar.YEAR, yyyy)
            set(java.util.Calendar.MONTH, (mm - 1).coerceIn(0, 11))
            set(java.util.Calendar.DAY_OF_MONTH, 1)
            set(java.util.Calendar.HOUR_OF_DAY, 0)
        }.timeInMillis
        val today = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }.timeInMillis
        val diffMs = target - today
        val days = (diffMs / (1000L * 60 * 60 * 24)).toInt()
        return days
    }
}
