package com.focusmode.discipline.net.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** Row in public.users. */
@Serializable
data class UserDto(
    val id: String,
    val name: String,
    val course: String? = null,
    val level: String? = null,
    val attempt: String? = null,
    @SerialName("avatar_letter") val avatarLetter: String? = null
)

/** Row in public.progress. */
@Serializable
data class ProgressDto(
    @SerialName("user_id") val userId: String,
    @SerialName("total_focus_minutes") val totalFocusMinutes: Int,
    @SerialName("chapters_completed") val chaptersCompleted: Int,
    @SerialName("lectures_completed") val lecturesCompleted: Int,
    @SerialName("revisions_completed") val revisionsCompleted: Int,
    @SerialName("streak_days") val streakDays: Int,
    @SerialName("last_active_date") val lastActiveDate: String? = null
)

/** Row returned by get_public_leaderboard / get_group_leaderboard SQL functions. */
@Serializable
data class LeaderboardRowDto(
    @SerialName("user_id") val userId: String,
    val name: String,
    @SerialName("avatar_letter") val avatarLetter: String? = null,
    val score: Int,
    val rank: Int
)

/** Row in public.groups. */
@Serializable
data class GroupDto(
    val id: String,
    val name: String,
    val description: String = "",
    @SerialName("invite_code") val inviteCode: String,
    @SerialName("owner_id") val ownerId: String? = null
)

/** Row in public.group_members. */
@Serializable
data class GroupMemberDto(
    @SerialName("group_id") val groupId: String,
    @SerialName("user_id") val userId: String
)

/** Row in public.friends. */
@Serializable
data class FriendDto(
    @SerialName("user_id") val userId: String,
    @SerialName("friend_id") val friendId: String
)

/** Args for the join_group_by_code RPC. */
@Serializable
data class JoinGroupArgs(@SerialName("p_code") val code: String)

/** Args for get_public_leaderboard RPC. */
@Serializable
data class PublicLbArgs(
    @SerialName("p_course") val course: String,
    @SerialName("p_level") val level: String,
    @SerialName("p_attempt") val attempt: String
)

/** Args for get_group_leaderboard RPC. */
@Serializable
data class GroupLbArgs(@SerialName("p_group_id") val groupId: String)
